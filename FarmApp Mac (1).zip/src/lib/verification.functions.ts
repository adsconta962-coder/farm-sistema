import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

/**
 * Retorna todos os tokens de verificacao de dominio do Facebook salvos nos
 * sites das empresas. Eles precisam ficar no DOMINIO RAIZ do painel, porque o
 * Meta so verifica dominio raiz (nao aceita /s/slug).
 */
export const getDomainVerificationTokens = createServerFn({ method: "GET" }).handler(
  async () => {
    const supabase = createClient<Database>(
      process.env["SUPABASE_URL"]!,
      process.env["SUPABASE_PUBLISHABLE_KEY"]!,
      { auth: { storage: undefined, persistSession: false, autoRefreshToken: false } },
    );
    const { data } = await supabase
      .from("company_sites")
      .select("meta_tag")
      .not("meta_tag", "is", null)
      .limit(500);

    const tokens = new Set<string>();
    for (const row of data ?? []) {
      const raw = row.meta_tag ?? "";
      const match = raw.match(/content=["']([a-z0-9]{10,})["']/i) ?? raw.match(/([a-z0-9]{20,})/i);
      if (match?.[1]) tokens.add(match[1]);
    }
    return { tokens: [...tokens] };
  },
);

export type InstanceStatus =
  | "rodando"
  | "parado"
  | "analise_pendente"
  | "restricao"
  | "molho"
  | "erro"
  | "concluido";

export type Instance = {
  id: string;
  user_id: string;
  name: string;
  short_id: string;
  status: InstanceStatus;
  step: number;
  total_steps: number;
  proxy: string | null;
  proxy_ip: string | null;
  profile_email: string | null;
  profile_password: string | null;
  profile_2fa?: string | null;

  cnpj?: string | null;
  company_name?: string | null;
  company_site?: string | null;
  meta_tag?: string | null;
  bm_id?: string | null;
  waba_created?: boolean | null;
  sms_number?: string | null;
  soak_mode?: boolean | null;
  direct_bm?: boolean | null;
  invert_flow?: boolean | null;
  auto_allocate?: boolean | null;
  site_theme?: string | null;
  tags: string[];
  notes: string | null;
  last_activity_at: string;
  created_at: string;
  updated_at: string;
};

export const STATUS_META: Record<
  InstanceStatus,
  { label: string; dot: string; chip: string }
> = {
  rodando: {
    label: "Rodando",
    dot: "bg-status-running",
    chip: "bg-status-running-soft text-status-running",
  },
  parado: {
    label: "Parado",
    dot: "bg-status-idle",
    chip: "bg-status-idle-soft text-status-idle",
  },
  analise_pendente: {
    label: "Análise pendente",
    dot: "bg-status-warn",
    chip: "bg-status-warn-soft text-status-warn",
  },
  restricao: {
    label: "Restrição",
    dot: "bg-status-danger",
    chip: "bg-status-danger-soft text-status-danger",
  },
  molho: {
    label: "Molho",
    dot: "bg-status-info",
    chip: "bg-status-info-soft text-status-info",
  },
  erro: {
    label: "Erro",
    dot: "bg-status-danger",
    chip: "bg-status-danger-soft text-status-danger",
  },
  concluido: {
    label: "Concluído",
    dot: "bg-status-running",
    chip: "bg-status-running-soft text-status-running",
  },
};

export const STATUS_OPTIONS = Object.keys(STATUS_META) as InstanceStatus[];

export function initials(name: string) {
  const clean = name.trim();
  if (!clean) return "??";
  return clean.slice(0, 2).toUpperCase();
}

export function relativeTime(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const minutes = Math.round(diff / 60000);
  if (minutes < 1) return "agora mesmo";
  if (minutes < 60) return `há ${minutes} min`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `há cerca de ${hours} horas`;
  const days = Math.round(hours / 24);
  return days === 1 ? "há 1 dia" : `há ${days} dias`;
}

export function progressPercent(step: number, total: number) {
  if (!total) return 0;
  return Math.min(100, Math.round((step / total) * 100));
}

/**
 * Parses a pasted/imported list. Accepted per line:
 *   Nome;email;senha;proxy
 * Separators: ";" , "|" or tab. Extra fields are ignored.
 */
export function parseImportText(text: string) {
  return text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const parts = line.split(/[;|\t]/).map((p) => p.trim());
      return {
        name: parts[0] ?? "",
        profile_email: parts[1] || null,
        profile_password: parts[2] || null,
        proxy: parts[3] || null,
      };
    })
    .filter((row) => row.name.length > 0);
}

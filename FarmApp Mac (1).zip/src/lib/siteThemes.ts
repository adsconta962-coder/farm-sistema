export type SiteTheme = {
  id: string;
  label: string;
  marca: string;
  marcaClaro: string;
  marcaEscuro: string;
  bg: string;
};

export const SITE_THEMES = [
  { id: "azul", label: "Azul Corporativo", marca: "#1e3a8a", marcaClaro: "#dbeafe", marcaEscuro: "#172554", bg: "#f3f6fd" },
  { id: "verde", label: "Verde Institucional", marca: "#166534", marcaClaro: "#dcfce7", marcaEscuro: "#052e16", bg: "#f2fbf5" },
  { id: "teal", label: "Teal Moderno", marca: "#0f766e", marcaClaro: "#ccfbf1", marcaEscuro: "#042f2e", bg: "#f0fbfa" },
  { id: "roxo", label: "Roxo Premium", marca: "#5b21b6", marcaClaro: "#ede9fe", marcaEscuro: "#2e1065", bg: "#f7f5ff" },
  { id: "vinho", label: "Vinho Clássico", marca: "#9f1239", marcaClaro: "#ffe4e6", marcaEscuro: "#4c0519", bg: "#fff5f6" },
  { id: "laranja", label: "Laranja Comercial", marca: "#c2410c", marcaClaro: "#ffedd5", marcaEscuro: "#431407", bg: "#fff7ed" },
  { id: "dourado", label: "Dourado Elegante", marca: "#a16207", marcaClaro: "#fef3c7", marcaEscuro: "#422006", bg: "#fffbeb" },
  { id: "grafite", label: "Grafite Sóbrio", marca: "#334155", marcaClaro: "#e2e8f0", marcaEscuro: "#0f172a", bg: "#f4f6f9" },
  { id: "rosa", label: "Rosa Boutique", marca: "#be185d", marcaClaro: "#fce7f3", marcaEscuro: "#500724", bg: "#fdf4f8" },
  { id: "ciano", label: "Ciano Tech", marca: "#0e7490", marcaClaro: "#cffafe", marcaEscuro: "#083344", bg: "#f0fbfe" },
] satisfies SiteTheme[];

export const getSiteTheme = (id?: string | null): SiteTheme =>
  SITE_THEMES.find((t) => t.id === id) ?? SITE_THEMES[0]!;

import { useState } from "react";
import {
  Coffee,
  ExternalLink,
  Globe,
  MoreHorizontal,
  Pencil,
  Play,
  MessageSquareMore,
  Square,
  TerminalSquare,
  Trash2,
  User2,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import type { Instance, InstanceStatus } from "@/lib/farm";
import { STATUS_META, initials, progressPercent, relativeTime } from "@/lib/farm";

type Props = {
  instances: Instance[];
  selected: string[];
  onToggle: (id: string) => void;
  onToggleAll: () => void;
  onEdit: (instance: Instance) => void;
  onStatus: (instance: Instance, status: InstanceStatus) => void;
  onDelete: (instance: Instance) => void;
};

function IconAction({
  label,
  onClick,
  children,
  tone = "muted",
}: {
  label: string;
  onClick: () => void;
  children: React.ReactNode;
  tone?: "muted" | "primary" | "danger";
}) {
  const toneClass =
    tone === "primary"
      ? "text-primary hover:bg-accent"
      : tone === "danger"
        ? "text-destructive hover:bg-destructive/10"
        : "text-muted-foreground hover:bg-muted";
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          type="button"
          aria-label={label}
          onClick={onClick}
          className={`inline-flex size-8 items-center justify-center rounded-md transition-colors ${toneClass}`}
        >
          {children}
        </button>
      </TooltipTrigger>
      <TooltipContent>{label}</TooltipContent>
    </Tooltip>
  );
}

export function InstancesTable({
  instances,
  selected,
  onToggle,
  onToggleAll,
  onEdit,
  onStatus,
  onDelete,
}: Props) {
  const [revealed, setRevealed] = useState<string[]>([]);
  const allChecked = instances.length > 0 && selected.length === instances.length;

  const copyCommand = (instance: Instance) => {
    const cmd = `node farm-agent.mjs run --instance ${instance.short_id}`;
    void navigator.clipboard.writeText(cmd);
    toast.success("Comando copiado", { description: cmd });
  };

  return (
    <div className="panel overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[1080px] text-sm">
          <thead>
            <tr className="border-b text-left text-xs font-medium text-muted-foreground">
              <th className="w-10 px-4 py-3">
                <Checkbox
                  checked={allChecked}
                  onCheckedChange={onToggleAll}
                  aria-label="Selecionar todas"
                />
              </th>
              <th className="px-2 py-3 font-medium">Instância</th>
              <th className="px-2 py-3 font-medium">Status</th>
              <th className="px-2 py-3 font-medium">Progresso</th>
              <th className="px-2 py-3 font-medium">Proxy</th>
              <th className="px-2 py-3 font-medium">Perfil</th>
              <th className="px-2 py-3 font-medium">Última Atividade</th>
              <th className="px-4 py-3 text-right font-medium">Ações</th>
            </tr>
          </thead>
          <tbody>
            {instances.map((instance) => {
              const meta = STATUS_META[instance.status];
              const pct = progressPercent(instance.step, instance.total_steps);
              const running = instance.status === "rodando";
              const waitingForSms =
                instance.status === "analise_pendente" && /SMS/i.test(instance.notes ?? "");
              const showPass = revealed.includes(instance.id);
              return (
                <tr key={instance.id} className="border-b last:border-0 hover:bg-muted/40">
                  <td className="px-4 py-3 align-top">
                    <Checkbox
                      checked={selected.includes(instance.id)}
                      onCheckedChange={() => onToggle(instance.id)}
                      aria-label={`Selecionar ${instance.name}`}
                    />
                  </td>
                  <td className="px-2 py-3">
                    <div className="flex items-center gap-3">
                      <div className="flex size-9 shrink-0 items-center justify-center rounded-full bg-accent text-xs font-semibold text-accent-foreground">
                        {initials(instance.name)}
                      </div>
                      <div className="min-w-0">
                        <div className="max-w-[220px] truncate font-medium">{instance.name}</div>
                        <div className="font-mono text-xs text-muted-foreground">
                          {instance.short_id}
                        </div>
                        {instance.tags.length > 0 && (
                          <div className="mt-1 flex flex-wrap gap-1">
                            {instance.tags.map((tag) => (
                              <span
                                key={tag}
                                className="rounded bg-muted px-1.5 py-0.5 text-[10px] text-muted-foreground"
                              >
                                {tag}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-2 py-3">
                    <span
                      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${meta.chip}`}
                    >
                      <span className={`size-1.5 rounded-full ${meta.dot}`} />
                      {meta.label}
                    </span>
                    {waitingForSms && (
                      <Button
                        type="button"
                        size="sm"
                        className="mt-2 h-8 whitespace-nowrap"
                        onClick={() => onStatus(instance, "rodando")}
                      >
                        <MessageSquareMore className="mr-1.5 size-3.5" />
                        Continuar após SMS
                      </Button>
                    )}
                  </td>
                  <td className="px-2 py-3">
                    {instance.step > 0 ? (
                      <div className="w-[110px]">
                        <div className="mb-1 flex justify-between font-mono text-[11px] text-muted-foreground">
                          <span>
                            {instance.step}/{instance.total_steps}
                          </span>
                          <span className="font-semibold text-foreground">{pct}%</span>
                        </div>
                        <div className="h-1.5 overflow-hidden rounded-full bg-muted">
                          <div
                            className="h-full rounded-full bg-primary transition-all"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </td>
                  <td className="px-2 py-3">
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Globe className="size-3.5" />
                      <span className="rounded bg-muted px-1.5 py-0.5">
                        {instance.proxy ?? "Sem proxy"}
                      </span>
                    </div>
                    {instance.proxy_ip && (
                      <div className="mt-1 font-mono text-[11px] text-muted-foreground">
                        IP: {instance.proxy_ip}
                      </div>
                    )}
                  </td>
                  <td className="px-2 py-3">
                    <div className="flex items-center gap-1.5">
                      <User2 className="size-3.5 text-muted-foreground" />
                      <span className="max-w-[200px] truncate text-xs">
                        {instance.profile_email ?? "—"}
                      </span>
                    </div>
                    <div className="mt-1 flex items-center gap-2">
                      <span className="font-mono text-[11px] text-muted-foreground">
                        Senha: {showPass ? (instance.profile_password ?? "—") : "••••••••"}
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          setRevealed((prev) =>
                            prev.includes(instance.id)
                              ? prev.filter((id) => id !== instance.id)
                              : [...prev, instance.id],
                          )
                        }
                        className="text-primary"
                        aria-label="Mostrar senha"
                      >
                        <ExternalLink className="size-3.5" />
                      </button>
                    </div>
                  </td>
                  <td className="px-2 py-3 text-xs text-muted-foreground">
                    {relativeTime(instance.last_activity_at)}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-0.5">
                      <IconAction label="Copiar comando local" onClick={() => copyCommand(instance)}>
                        <TerminalSquare className="size-4" />
                      </IconAction>
                      <IconAction label="Editar" onClick={() => onEdit(instance)}>
                        <Pencil className="size-4" />
                      </IconAction>
                      {running ? (
                        <IconAction
                          label="Parar"
                          tone="danger"
                          onClick={() => onStatus(instance, "parado")}
                        >
                          <Square className="size-4" />
                        </IconAction>
                      ) : waitingForSms ? (
                        <IconAction
                          label="Continuar após SMS"
                          tone="primary"
                          onClick={() => onStatus(instance, "rodando")}
                        >
                          <MessageSquareMore className="size-4" />
                        </IconAction>
                      ) : (
                        <IconAction
                          label="Iniciar"
                          tone="primary"
                          onClick={() => onStatus(instance, "rodando")}
                        >
                          <Play className="size-4" />
                        </IconAction>
                      )}
                      <IconAction label="Molho" onClick={() => onStatus(instance, "molho")}>
                        <Coffee className="size-4" />
                      </IconAction>
                      <DropdownMenu>
                        <DropdownMenuTrigger
                          aria-label="Mais ações"
                          className="inline-flex size-8 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted"
                        >
                          <MoreHorizontal className="size-4" />
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onStatus(instance, "analise_pendente")}>
                            Marcar análise pendente
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => onStatus(instance, "restricao")}>
                            Marcar restrição
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => onStatus(instance, "concluido")}>
                            Marcar concluído
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="text-destructive"
                            onClick={() => onDelete(instance)}
                          >
                            <Trash2 className="mr-2 size-4" /> Excluir
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {instances.length === 0 && (
        <div className="px-6 py-16 text-center text-sm text-muted-foreground">
          Nenhuma instância encontrada.
        </div>
      )}
    </div>
  );
}

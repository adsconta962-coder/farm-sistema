import { useEffect, useState } from "react";
import { Palette, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import type { Instance, InstanceStatus } from "@/lib/farm";
import { STATUS_META, STATUS_OPTIONS } from "@/lib/farm";
import { SITE_THEMES, getSiteTheme } from "@/lib/siteThemes";

export type InstanceDraft = {
  name: string;
  status: InstanceStatus;
  step: number;
  total_steps: number;
  proxy: string | null;
  proxy_ip: string | null;
  profile_email: string | null;
  profile_password: string | null;
  profile_2fa: string | null;

  cnpj: string | null;
  notes: string | null;
  tags: string[];
  soak_mode: boolean;
  direct_bm: boolean;
  invert_flow: boolean;
  auto_allocate: boolean;
  site_theme: string;
};

const empty: InstanceDraft = {
  name: "",
  status: "parado",
  step: 0,
  total_steps: 13,
  proxy: null,
  proxy_ip: null,
  profile_email: null,
  profile_password: null,
  profile_2fa: null,

  cnpj: null,
  notes: null,
  tags: [],
  soak_mode: false,
  direct_bm: false,
  invert_flow: false,
  auto_allocate: true,
  site_theme: "azul",
};

function OptionToggle({
  title,
  description,
  checked,
  onCheckedChange,
}: {
  title: string;
  description: string;
  checked: boolean;
  onCheckedChange: (value: boolean) => void;
}) {
  return (
    <div className="flex items-start justify-between gap-4 rounded-lg border bg-muted/40 p-3">
      <div className="space-y-0.5">
        <p className="text-sm font-semibold text-primary">{title}</p>
        <p className="text-xs text-muted-foreground">{description}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onCheckedChange} />
    </div>
  );
}

export function InstanceFormDialog({
  open,
  onOpenChange,
  instance,
  onSubmit,
  pending,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  instance: Instance | null;
  onSubmit: (draft: InstanceDraft) => void;
  pending: boolean;
}) {
  const [draft, setDraft] = useState<InstanceDraft>(empty);
  const [tagsText, setTagsText] = useState("");

  useEffect(() => {
    if (!open) return;
    setTagsText(instance?.tags?.join(", ") ?? "");
    setDraft(
      instance
        ? {
            name: instance.name,
            status: instance.status,
            step: instance.step,
            total_steps: instance.total_steps,
            proxy: instance.proxy,
            proxy_ip: instance.proxy_ip,
            profile_email: instance.profile_email,
            profile_password: instance.profile_password,
            profile_2fa: instance.profile_2fa ?? null,

            cnpj: instance.cnpj ?? null,
            notes: instance.notes,
            tags: instance.tags ?? [],
            soak_mode: instance.soak_mode ?? false,
            direct_bm: instance.direct_bm ?? false,
            invert_flow: instance.invert_flow ?? false,
            auto_allocate: instance.auto_allocate ?? true,
            site_theme: instance.site_theme ?? "azul",
          }
        : empty,
    );
  }, [open, instance]);

  const set = <K extends keyof InstanceDraft>(key: K, value: InstanceDraft[K]) =>
    setDraft((prev) => ({ ...prev, [key]: value }));

  const submit = () =>
    onSubmit({
      ...draft,
      tags: tagsText
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean),
    });

  const theme = getSiteTheme(draft.site_theme);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{instance ? "Editar instância" : "Nova instância"}</DialogTitle>
          <DialogDescription>
            Dados usados pelo agente local ao abrir o perfil e executar as etapas.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="name">Nome da instância</Label>
            <Input
              id="name"
              value={draft.name}
              onChange={(e) => set("name", e.target.value)}
              placeholder="Ana Lucia Costa Santos"
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="tags">Tags (separadas por vírgula)</Label>
            <Input
              id="tags"
              value={tagsText}
              onChange={(e) => setTagsText(e.target.value)}
              placeholder="Ex: BM250, Suporte, Principal"
            />
          </div>

          <OptionToggle
            title="Deixar de Molho"
            description="Parar automaticamente e mudar a tag após a verificação do domínio."
            checked={draft.soak_mode}
            onCheckedChange={(v) => set("soak_mode", v)}
          />
          <OptionToggle
            title="Criar BM Direto (Loginpage)"
            description="Cria o portfólio comercial rapidamente usando a URL loginpage sem passar pelo Ads Manager."
            checked={draft.direct_bm}
            onCheckedChange={(v) => set("direct_bm", v)}
          />
          <OptionToggle
            title="Inverter Fluxo (Domínio Primeiro)"
            description="Registra o domínio no Meta antes de preencher as informações da empresa, finalizando a verificação do domínio no final."
            checked={draft.invert_flow}
            onCheckedChange={(v) => set("invert_flow", v)}
          />

          <div className="rounded-lg border bg-muted/40 p-3">
            <p className="flex items-center gap-2 text-sm font-semibold text-primary">
              <Palette className="size-4" /> Modelo do Site (tema)
            </p>
            <p className="mt-0.5 text-xs text-muted-foreground">
              Design do site institucional gerado para verificação de domínio.
            </p>
            <Select value={draft.site_theme} onValueChange={(v) => set("site_theme", v)}>
              <SelectTrigger className="mt-3">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {SITE_THEMES.map((t) => (
                  <SelectItem key={t.id} value={t.id}>
                    <span className="flex items-center gap-2">
                      <span
                        className="size-3 rounded-full"
                        style={{ backgroundColor: t.marca }}
                      />
                      {t.label}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {SITE_THEMES.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  title={t.label}
                  aria-label={t.label}
                  onClick={() => set("site_theme", t.id)}
                  style={{ backgroundColor: t.marca }}
                  className={`size-5 rounded-full border-2 transition-transform ${
                    draft.site_theme === t.id ? "scale-110 border-foreground" : "border-transparent"
                  }`}
                />
              ))}
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Selecionado: {theme.label}</p>
          </div>

          <OptionToggle
            title="Alocação Automática Ativa"
            description="O sistema vincula automaticamente um perfil do Facebook e um CNPJ disponíveis para esta instância logo após a criação."
            checked={draft.auto_allocate}
            onCheckedChange={(v) => set("auto_allocate", v)}
          />

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label>Status</Label>
              <Select
                value={draft.status}
                onValueChange={(value) => set("status", value as InstanceStatus)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STATUS_OPTIONS.map((status) => (
                    <SelectItem key={status} value={status}>
                      {STATUS_META[status].label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="grid gap-2">
                <Label htmlFor="step">Etapa</Label>
                <Input
                  id="step"
                  type="number"
                  min={0}
                  value={draft.step}
                  onChange={(e) => set("step", Number(e.target.value))}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="total">Total</Label>
                <Input
                  id="total"
                  type="number"
                  min={1}
                  value={draft.total_steps}
                  onChange={(e) => set("total_steps", Number(e.target.value) || 1)}
                />
              </div>
            </div>
          </div>

          <div className="grid gap-2 rounded-lg border border-border/60 bg-muted/30 p-3">
            <Label htmlFor="paste-line">Colar linha do perfil</Label>
            <Input
              id="paste-line"
              placeholder="ID|senha|2FA|email"
              onChange={(e) => {
                const raw = e.target.value.trim();
                if (!raw.includes("|")) return;
                const [id, pass, tfa, mail] = raw.split("|").map((p) => p.trim());
                if (id) set("profile_email", id);
                if (pass) set("profile_password", pass);
                if (tfa) set("profile_2fa", tfa);
                if (mail) {
                  set(
                    "notes",
                    [draft.notes, `E-mail do perfil: ${mail}`].filter(Boolean).join(" · "),
                  );
                }
                e.target.value = "";
              }}
            />
            <p className="text-xs text-muted-foreground">
              Ordem: identificação do perfil · senha · segredo 2FA · e-mail. Ao colar, os campos
              abaixo são preenchidos automaticamente.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">

            <div className="grid gap-2">
              <Label htmlFor="email">Login do perfil (ID ou e-mail)</Label>
              <Input
                id="email"
                value={draft.profile_email ?? ""}
                onChange={(e) => set("profile_email", e.target.value || null)}
                placeholder="61580296264662"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="pass">Senha do perfil</Label>
              <Input
                id="pass"
                value={draft.profile_password ?? ""}
                onChange={(e) => set("profile_password", e.target.value || null)}
              />
            </div>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="tfa">Segredo 2FA do perfil (opcional)</Label>
            <Input
              id="tfa"
              value={draft.profile_2fa ?? ""}
              onChange={(e) => set("profile_2fa", e.target.value || null)}
              placeholder="chave de configuração do app de autenticação"
            />
            <p className="text-xs text-muted-foreground">
              Usado pelo agente local para gerar o código de 6 dígitos no checkpoint do Facebook.
            </p>
          </div>


          <div className="grid gap-2">
            <Label htmlFor="cnpj">CNPJ da empresa</Label>
            <Input
              id="cnpj"
              value={draft.cnpj ?? ""}
              onChange={(e) => set("cnpj", e.target.value || null)}
              placeholder="00.000.000/0000-00"
            />
            <p className="text-xs text-muted-foreground">
              O agente busca razão social, endereço e telefone só pelo número.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="proxy">Proxy</Label>
              <Input
                id="proxy"
                value={draft.proxy ?? ""}
                onChange={(e) => set("proxy", e.target.value || null)}
                placeholder="Sem proxy"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="ip">IP do proxy</Label>
              <Input
                id="ip"
                value={draft.proxy_ip ?? ""}
                onChange={(e) => set("proxy_ip", e.target.value || null)}
                placeholder="177.173.239.28"
              />
            </div>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="notes">Observações</Label>
            <Textarea
              id="notes"
              value={draft.notes ?? ""}
              onChange={(e) => set("notes", e.target.value || null)}
              rows={3}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button disabled={pending || !draft.name.trim()} onClick={submit}>
            <Sparkles className="mr-2 size-4" />
            {instance ? "Salvar" : "Criar instância"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

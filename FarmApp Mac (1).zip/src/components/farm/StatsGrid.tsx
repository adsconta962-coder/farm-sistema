import { Activity, CheckCircle2, LayoutList, TrendingUp, TriangleAlert } from "lucide-react";
import type { Instance } from "@/lib/farm";
import { progressPercent } from "@/lib/farm";

function StatCard({
  icon: Icon,
  value,
  label,
  hint,
}: {
  icon: typeof Activity;
  value: string;
  label: string;
  hint: string;
}) {
  return (
    <div className="panel p-5">
      <div className="mb-6 flex size-10 items-center justify-center rounded-lg bg-muted text-muted-foreground">
        <Icon className="size-5" />
      </div>
      <div className="text-3xl font-semibold tracking-tight">{value}</div>
      <div className="mt-1 text-sm font-medium">{label}</div>
      <div className="mt-0.5 text-xs text-muted-foreground">{hint}</div>
    </div>
  );
}

export function StatsGrid({ instances }: { instances: Instance[] }) {
  const total = instances.length;
  const active = instances.filter((i) => i.status === "rodando").length;
  const doneSteps = instances.reduce((sum, i) => sum + i.step, 0);
  const errors = instances.filter((i) => i.status === "erro" || i.status === "restricao").length;
  const errorRate = total ? (errors / total) * 100 : 0;
  const avgProgress = total
    ? Math.round(
        instances.reduce((sum, i) => sum + progressPercent(i.step, i.total_steps), 0) / total,
      )
    : 0;

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
      <StatCard
        icon={LayoutList}
        value={String(total)}
        label="Total de Instâncias"
        hint="Instâncias cadastradas"
      />
      <StatCard
        icon={Activity}
        value={String(active)}
        label="Instâncias Ativas"
        hint={`${total ? Math.round((active / total) * 100) : 0}% do total`}
      />
      <StatCard
        icon={CheckCircle2}
        value={String(doneSteps)}
        label="Tarefas Concluídas"
        hint="Etapas Meta somadas"
      />
      <StatCard
        icon={TriangleAlert}
        value={`${errorRate.toFixed(1)}%`}
        label="Taxa de Erro"
        hint={errorRate < 5 ? "Dentro do esperado" : "Acima do esperado"}
      />
      <StatCard
        icon={TrendingUp}
        value={`${avgProgress}%`}
        label="Progresso Médio"
        hint="Todas instâncias"
      />
    </div>
  );
}

import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { parseImportText } from "@/lib/farm";

export function ImportDialog({
  open,
  onOpenChange,
  onImport,
  pending,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onImport: (rows: ReturnType<typeof parseImportText>) => void;
  pending: boolean;
}) {
  const [text, setText] = useState("");
  const rows = parseImportText(text);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Importar instâncias</DialogTitle>
          <DialogDescription>
            Uma por linha, no formato <span className="font-mono">Nome;email;senha;proxy</span>.
            Também aceita separador <span className="font-mono">|</span> ou tabulação.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-2">
          <Label htmlFor="import">Lista</Label>
          <Textarea
            id="import"
            rows={10}
            className="font-mono text-xs"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={"Ana Lucia Costa;rg1urrs2@end.tw;Rafi@0s2JEgypt;Sem proxy"}
          />
          <p className="text-xs text-muted-foreground">
            {rows.length} instância(s) reconhecida(s).
          </p>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button disabled={pending || rows.length === 0} onClick={() => onImport(rows)}>
            Importar {rows.length > 0 ? `(${rows.length})` : ""}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

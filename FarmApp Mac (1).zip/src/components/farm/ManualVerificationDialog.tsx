import { useState } from "react";
import { Building2, Copy, FileText, Globe, Loader2, Search } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { SITE_THEMES } from "@/lib/siteThemes";

type CompanyForm = {
  cnpj: string;
  tradeName: string;
  legalName: string;
  owner: string;
  email: string;
  phone: string;
  zip: string;
  address: string;
  complement: string;
  district: string;
  city: string;
  state: string;
  about: string;
  openingDate: string;
  cnae: string;
  legalNature: string;
  companySize: string;
  capital: string;
  situation: string;
  unitType: string;
};

const emptyForm: CompanyForm = {
  cnpj: "",
  tradeName: "",
  legalName: "",
  owner: "",
  email: "",
  phone: "",
  zip: "",
  address: "",
  complement: "",
  district: "",
  city: "",
  state: "",
  about: "",
  openingDate: "",
  cnae: "",
  legalNature: "",
  companySize: "",
  capital: "",
  situation: "",
  unitType: "",
};

export { SITE_THEMES };


function slugify(text: string, fallback: string) {
  const slug = text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 40);
  return slug || fallback;
}

function CopyField({
  id,
  label,
  value,
  onChange,
  placeholder,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}) {
  return (
    <div className="grid gap-1.5">
      <Label htmlFor={id} className="text-xs text-muted-foreground">
        {label}
      </Label>
      <div className="relative">
        <Input
          id={id}
          value={value}
          placeholder={placeholder}
          onChange={(e) => onChange(e.target.value)}
          className="pr-9"
        />
        <button
          type="button"
          aria-label={`Copiar ${label}`}
          onClick={() => {
            if (!value) return;
            void navigator.clipboard.writeText(value);
            toast.success(`${label} copiado`);
          }}
          className="absolute right-1 top-1/2 inline-flex size-7 -translate-y-1/2 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted"
        >
          <Copy className="size-3.5" />
        </button>
      </div>
    </div>
  );
}

export function ManualVerificationDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [form, setForm] = useState<CompanyForm>(emptyForm);
  const [theme, setTheme] = useState<string>(SITE_THEMES[0]!.id);
  const [metaTag, setMetaTag] = useState("");
  const [siteUrl, setSiteUrl] = useState<string | null>(null);
  const [slug, setSlug] = useState<string | null>(null);
  const [loadingCnpj, setLoadingCnpj] = useState(false);
  const [publishing, setPublishing] = useState(false);

  const changeTheme = (value: string) => {
    setTheme(value);
    if (!slug) return;
    void supabase
      .from("company_sites")
      .update({ theme: value })
      .eq("slug", slug)
      .then(({ error }) =>
        error ? toast.error(error.message) : toast.success("Cor do site atualizada"),
      );
  };

  const set = <K extends keyof CompanyForm>(key: K, value: CompanyForm[K]) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const lookupAndCreate = async () => {
    const digits = form.cnpj.replace(/\D/g, "");
    if (digits.length !== 14) {
      toast.error("Informe um CNPJ com 14 dígitos");
      return;
    }
    setLoadingCnpj(true);
    try {
      const res = await fetch(`https://brasilapi.com.br/api/cnpj/v1/${digits}`);
      if (!res.ok) throw new Error("CNPJ não encontrado na base pública");
      const d = (await res.json()) as Record<string, string>;
      const next: CompanyForm = {
        ...form,
        cnpj: digits.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, "$1.$2.$3/$4-$5"),
        tradeName: d["nome_fantasia"] || d["razao_social"] || "",
        legalName: d["razao_social"] || "",
        owner: (d["qsa"] as unknown as Array<{ nome_socio?: string }> | undefined)?.[0]
          ?.nome_socio || form.owner,
        email: d["email"] || form.email,
        phone: d["ddd_telefone_1"] || form.phone,
        zip: (d["cep"] || "").replace(/^(\d{5})(\d{3})$/, "$1-$2"),
        address: [d["descricao_tipo_de_logradouro"], d["logradouro"], d["numero"]]
          .filter(Boolean)
          .join(" "),
        complement: d["complemento"] || "",
        district: d["bairro"] || "",
        city: d["municipio"] || "",
        state: d["uf"] || "",
        about: d["cnae_fiscal_descricao"] || "",
        openingDate: d["data_inicio_atividade"]
          ? String(d["data_inicio_atividade"]).split("-").reverse().join("/")
          : "",
        cnae: [d["cnae_fiscal"], d["cnae_fiscal_descricao"]].filter(Boolean).join(" — "),
        legalNature: d["descricao_natureza_juridica"] || "",
        companySize: d["porte"] || "",
        capital: d["capital_social"]
          ? Number(d["capital_social"]).toLocaleString("pt-BR", {
              style: "currency",
              currency: "BRL",
            })
          : "",
        situation: d["descricao_situacao_cadastral"] || "",
        unitType: d["descricao_identificador_matriz_filial"] || "",
      };
      setForm(next);
      await publishSite(next);
    } catch (error) {
      toast.error("Falha na consulta do CNPJ", { description: (error as Error).message });
    } finally {
      setLoadingCnpj(false);
    }
  };

  const publishSite = async (data: CompanyForm) => {
    setPublishing(true);
    try {
      const { data: auth } = await supabase.auth.getUser();
      const userId = auth.user?.id;
      if (!userId) throw new Error("Sessão inválida");
      const base = slugify(data.tradeName || data.legalName, "empresa");
      const finalSlug = `${base}-${Math.random().toString(36).slice(2, 8)}`;
      const { error } = await supabase.from("company_sites").insert({
        user_id: userId,
        slug: finalSlug,
        theme,
        company_name: data.tradeName || data.legalName,
        legal_name: data.legalName || null,
        trade_name: data.tradeName || null,
        owner_name: data.owner || null,
        cnpj: data.cnpj,
        email: data.email || null,
        phone: data.phone || null,
        opening_date: data.openingDate || null,
        cnae: data.cnae || null,
        legal_nature: data.legalNature || null,
        company_size: data.companySize || null,
        capital: data.capital || null,
        situation: data.situation || null,
        unit_type: data.unitType || null,
        street: [data.address, data.complement].filter(Boolean).join(", ") || null,
        complement: data.complement || null,
        district: data.district || null,
        city: data.city || null,
        state: data.state || null,
        zip: data.zip || null,
        address: [data.address, data.complement, data.district, [data.city, data.state].filter(Boolean).join("/"), data.zip ? `CEP ${data.zip}` : ""]
          .filter(Boolean)
          .join(", "),
        about: data.about || null,
      });

      if (error) throw error;
      setSlug(finalSlug);
      setSiteUrl(`${window.location.origin}/s/${finalSlug}`);
      toast.success("Site institucional criado");
    } catch (error) {
      toast.error("Falha ao criar o site", { description: (error as Error).message });
    } finally {
      setPublishing(false);
    }
  };

  const saveMetaTag = async () => {
    if (!slug) {
      toast.error("Crie o site antes de salvar a meta tag");
      return;
    }
    const { error } = await supabase
      .from("company_sites")
      .update({ meta_tag: metaTag || null })
      .eq("slug", slug);
    if (error) {
      toast.error("Falha ao salvar a meta tag", { description: error.message });
      return;
    }
    toast.success("Meta tag publicada no site");
  };

  const generatePdf = () => {
    const rows: Array<[string, string]> = [
      ["CNPJ", form.cnpj],
      ["Razão Social", form.legalName],
      ["Nome Fantasia", form.tradeName],
      ["Sócio / Proprietário", form.owner],
      ["E-mail", form.email],
      ["Telefone", form.phone],
      ["Endereço", [form.address, form.complement, form.district].filter(Boolean).join(", ")],
      ["Cidade / UF", [form.city, form.state].filter(Boolean).join(" / ")],
      ["CEP", form.zip],
      ["Site", siteUrl ?? "—"],
    ];
    const win = window.open("", "_blank");
    if (!win) {
      toast.error("Permita pop-ups para gerar o comprovante");
      return;
    }
    win.document.write(`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8">
<title>Comprovante — ${form.legalName || form.tradeName}</title>
<style>body{font-family:system-ui,sans-serif;padding:48px;color:#111}h1{font-size:20px;margin-bottom:4px}
p.sub{color:#666;font-size:12px;margin-top:0}table{width:100%;border-collapse:collapse;margin-top:24px;font-size:13px}
td{border-bottom:1px solid #e5e5e5;padding:10px 4px}td:first-child{color:#666;width:220px}</style></head><body>
<h1>${form.legalName || form.tradeName || "Empresa"}</h1>
<p class="sub">Comprovante de dados cadastrais · emitido em ${new Date().toLocaleString("pt-BR")}</p>
<table>${rows.map(([k, v]) => `<tr><td>${k}</td><td>${v || "—"}</td></tr>`).join("")}</table>
</body></html>`);
    win.document.close();
    win.focus();
    win.print();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-4xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Building2 className="size-5 text-primary" /> Cockpit de Verificação Manual
          </DialogTitle>
          <DialogDescription>
            Utilitário manual para consulta de CNPJ, deploy do site institucional, meta tag e geração
            de comprovante em PDF.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-6 lg:grid-cols-2">
          <section className="panel space-y-4 p-5">
            <h3 className="border-b pb-3 text-sm font-semibold">1. Informações Cadastrais (CNPJ)</h3>

            <div className="flex flex-col gap-2 sm:flex-row">
              <Input
                value={form.cnpj}
                onChange={(e) => set("cnpj", e.target.value)}
                placeholder="00.000.000/0000-00"
              />
              <Button onClick={() => void lookupAndCreate()} disabled={loadingCnpj || publishing}>
                {loadingCnpj || publishing ? (
                  <Loader2 className="mr-2 size-4 animate-spin" />
                ) : (
                  <Search className="mr-2 size-4" />
                )}
                Buscar CNPJ &amp; Criar Site
              </Button>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <CopyField
                id="mv-cnpj"
                label="CNPJ"
                value={form.cnpj}
                onChange={(v) => set("cnpj", v)}
              />
              <CopyField
                id="mv-fantasia"
                label="Nome Fantasia"
                value={form.tradeName}
                onChange={(v) => set("tradeName", v)}
                placeholder="Ex: Nova Era Ltda"
              />
            </div>
            <CopyField
              id="mv-razao"
              label="Razão Social"
              value={form.legalName}
              onChange={(v) => set("legalName", v)}
              placeholder="Razão Social Completa"
            />
            <div className="grid gap-3 sm:grid-cols-2">
              <CopyField
                id="mv-socio"
                label="Sócio / Proprietário"
                value={form.owner}
                onChange={(v) => set("owner", v)}
                placeholder="Nome Completo do Sócio"
              />
              <CopyField
                id="mv-email"
                label="E-mail"
                value={form.email}
                onChange={(v) => set("email", v)}
                placeholder="contato@empresa.com"
              />
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <CopyField
                id="mv-tel"
                label="Telefone"
                value={form.phone}
                onChange={(v) => set("phone", v)}
                placeholder="11999998888"
              />
              <CopyField
                id="mv-cep"
                label="CEP"
                value={form.zip}
                onChange={(v) => set("zip", v)}
                placeholder="01001000"
              />
            </div>
            <CopyField
              id="mv-end"
              label="Endereço Completo"
              value={form.address}
              onChange={(v) => set("address", v)}
              placeholder="Av Paulista, 1000"
            />
            <CopyField
              id="mv-comp"
              label="Complemento"
              value={form.complement}
              onChange={(v) => set("complement", v)}
              placeholder="Sala, bloco, etc."
            />
            <div className="grid gap-3 sm:grid-cols-2">
              <CopyField
                id="mv-bairro"
                label="Bairro"
                value={form.district}
                onChange={(v) => set("district", v)}
                placeholder="Bairro"
              />
              <CopyField
                id="mv-cidade"
                label="Cidade"
                value={form.city}
                onChange={(v) => set("city", v)}
                placeholder="São Paulo"
              />
            </div>
            <CopyField
              id="mv-uf"
              label="Estado (UF)"
              value={form.state}
              onChange={(v) => set("state", v)}
              placeholder="SP"
            />
          </section>

          <div className="space-y-6">
            <section className="panel space-y-4 p-5">
              <h3 className="flex items-center gap-2 border-b pb-3 text-sm font-semibold">
                <Globe className="size-4 text-primary" /> 2. Site Institucional
              </h3>

              <div className="grid gap-1.5">
                <Label className="text-xs text-muted-foreground">Cor / Modelo do Site</Label>
                <Select value={theme} onValueChange={changeTheme}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SITE_THEMES.map((item) => (
                      <SelectItem key={item.id} value={item.id}>
                        <span className="flex items-center gap-2">
                          <span
                            className="size-3 rounded-full border"
                            style={{ backgroundColor: item.marca }}
                          />
                          {item.label}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="mt-1 flex flex-wrap gap-1.5">
                  {SITE_THEMES.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      title={item.label}
                      aria-label={item.label}
                      onClick={() => changeTheme(item.id)}
                      style={{ backgroundColor: item.marca }}
                      className={`size-6 rounded-full border-2 transition-transform ${
                        theme === item.id ? "scale-110 border-foreground" : "border-transparent"
                      }`}
                    />
                  ))}
                </div>
              </div>


              <div className="grid gap-1.5">
                <Label className="text-xs text-muted-foreground">URL publicada</Label>
                <div className="flex items-center gap-2">
                  <Input readOnly value={siteUrl ?? "—"} className="font-mono text-xs" />
                  <Button
                    variant="outline"
                    size="icon"
                    aria-label="Copiar URL"
                    disabled={!siteUrl}
                    onClick={() => {
                      if (siteUrl) {
                        void navigator.clipboard.writeText(siteUrl);
                        toast.success("URL copiada");
                      }
                    }}
                  >
                    <Copy className="size-4" />
                  </Button>
                </div>
              </div>

              <div className="grid gap-1.5">
                <Label htmlFor="mv-meta" className="text-xs text-muted-foreground">
                  Meta tag do Facebook
                </Label>
                <Textarea
                  id="mv-meta"
                  rows={3}
                  value={metaTag}
                  onChange={(e) => setMetaTag(e.target.value)}
                  placeholder='<meta name="facebook-domain-verification" content="..." />'
                />
                <Button variant="outline" onClick={() => void saveMetaTag()} disabled={!slug}>
                  Publicar meta tag no site
                </Button>
              </div>
            </section>

            <section className="panel space-y-3 p-5">
              <h3 className="flex items-center gap-2 border-b pb-3 text-sm font-semibold">
                <FileText className="size-4 text-primary" /> 3. Comprovante
              </h3>
              <p className="text-xs text-muted-foreground">
                Gera o comprovante com os dados cadastrais acima, usado no upload do wizard de
                verificação do Facebook.
              </p>
              <Button className="w-full" onClick={generatePdf}>
                <FileText className="mr-2 size-4" /> Gerar &amp; Baixar Comprovante PDF
              </Button>
            </section>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

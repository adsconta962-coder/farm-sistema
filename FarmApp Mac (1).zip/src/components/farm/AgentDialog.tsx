import { Copy, Terminal } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const INSTALL_CMD =
  "curl -fsSL https://macbook-farm-app.lovable.app/api/public/install-agent | bash";
const RESTART_CMD = "cd ~/farm-agent && node farm-agent.mjs watch";

function CommandBox({ label, cmd }: { label: string; cmd: string }) {
  return (
    <div className="space-y-2">
      <p className="text-sm font-medium">{label}</p>
      <div className="flex items-center gap-2 rounded-md border bg-muted/40 p-3">
        <code className="flex-1 break-all font-mono text-xs">{cmd}</code>
        <Button
          size="icon"
          variant="ghost"
          onClick={() => {
            navigator.clipboard.writeText(cmd);
            toast.success("Comando copiado");
          }}
          aria-label="Copiar comando"
        >
          <Copy className="size-4" />
        </Button>
      </div>
    </div>
  );
}

export function AgentDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Terminal className="size-5" /> Agente local (macOS)
          </DialogTitle>
          <DialogDescription>
            O painel é online, mas quem abre os perfis do Facebook no seu Mac é o agente local.
            Abra o Terminal (Command + Espaço → "Terminal"), cole o comando abaixo e pressione
            Enter.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5">
          <CommandBox label="1. Instalar e ligar o agente (uma única vez)" cmd={INSTALL_CMD} />
          <CommandBox label="2. Ligar novamente depois (nas próximas vezes)" cmd={RESTART_CMD} />

          <ol className="list-decimal space-y-1 pl-5 text-sm text-muted-foreground">
            <li>Ele instala o Node/Chromium necessário e pede seu e-mail e senha do painel.</li>
            <li>Deixe a janela do Terminal aberta enquanto estiver farmando.</li>
            <li>
              Ao clicar em ▶ numa instância aqui no painel, o navegador abre automaticamente no
              Mac e o progresso volta para esta tela.
            </li>
          </ol>
          <p className="text-xs text-muted-foreground">
            Se aparecer "Node.js não encontrado", instale com <code>brew install node</code> (ou
            baixe em nodejs.org) e rode o comando novamente.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}

import { createFileRoute } from "@tanstack/react-router";

import pkg from "../../../../agent/package.json?raw";
import cli from "../../../../agent/farm-agent.mjs?raw";
import libApi from "../../../../agent/lib/api.mjs?raw";
import libBrowser from "../../../../agent/lib/browser.mjs?raw";
import libCaptcha from "../../../../agent/lib/captcha.mjs?raw";
import libCnpj from "../../../../agent/lib/cnpj.mjs?raw";
import libConfig from "../../../../agent/lib/config.mjs?raw";
import libHuman from "../../../../agent/lib/human.mjs?raw";
import libSite from "../../../../agent/lib/site.mjs?raw";
import libSms from "../../../../agent/lib/sms.mjs?raw";
import libTotp from "../../../../agent/lib/totp.mjs?raw";
import taskDefault from "../../../../agent/tasks/default.mjs?raw";

const SUPABASE_URL = "https://gmmmsxjpctibsygaxprt.supabase.co";
const SUPABASE_KEY = "sb_publishable_EAQeKe4HlcWwA74b4hBqyA_9uV4H0y3";
const PANEL_URL = "https://macbook-farm-app.lovable.app";

const buildEnvFile = (captchaKey: string) => `FARM_SUPABASE_URL=${SUPABASE_URL}
FARM_SUPABASE_KEY=${SUPABASE_KEY}
FARM_PANEL_URL=${PANEL_URL}
FARM_POLL_MS=10000
FARM_CONCURRENCY=2
FARM_HEADLESS=false
FARM_SPEED=0.6
FARM_SHOW_MS=9000
FARM_KEEP_OPEN=true
FARM_KEEP_OPEN_SECONDS=0
FARM_SMS_API_URL=https://api.sms24h.org/stubs/handler_api
FARM_SMS_API_KEY=a0c9202f39c2b6d4156cf4f3ff01753d
FARM_SMS_SERVICE=fb
FARM_SMS_COUNTRY=73
FARM_CAPTCHA_API_URL=https://api.2captcha.com
FARM_CAPTCHA_API_KEY=${captchaKey}
`;

const buildFiles = (captchaKey: string): Record<string, string> => ({
  "package.json": pkg,
  "farm-agent.mjs": cli,
  ".env": buildEnvFile(captchaKey),
  "lib/api.mjs": libApi,
  "lib/browser.mjs": libBrowser,
  "lib/captcha.mjs": libCaptcha,
  "lib/cnpj.mjs": libCnpj,
  "lib/config.mjs": libConfig,
  "lib/human.mjs": libHuman,
  "lib/site.mjs": libSite,
  "lib/sms.mjs": libSms,
  "lib/totp.mjs": libTotp,
  "tasks/default.mjs": taskDefault,
});

function heredoc(path: string, content: string) {
  return `mkdir -p "$(dirname "$DIR/${path}")"\ncat > "$DIR/${path}" <<'FARM_EOF_${path.replace(/[^A-Za-z0-9]/g, "_")}'\n${content}\nFARM_EOF_${path.replace(/[^A-Za-z0-9]/g, "_")}\n`;
}

function buildScript(captchaKey: string) {
  const files = buildFiles(captchaKey);
  return `#!/bin/bash
set -e

DIR="$HOME/farm-agent"
echo ""
echo "==> Instalando o FARM Agent em $DIR"
mkdir -p "$DIR"

pick_node() {
  for c in "$@"; do
    if [ -x "$c" ]; then
      v="$("$c" -v 2>/dev/null | sed 's/^v//' | cut -d. -f1)"
      if [ -n "$v" ] && [ "$v" -ge 20 ] 2>/dev/null; then echo "$c"; return 0; fi
    fi
  done
  return 1
}

NODE_BIN="$(pick_node /usr/local/bin/node /opt/homebrew/bin/node "$(command -v node 2>/dev/null)" || true)"
if [ -z "$NODE_BIN" ]; then
  echo "!! Node.js 20 ou superior nao encontrado."
  echo "   Baixe o instalador LTS em https://nodejs.org/pt-br/download e rode este comando de novo."
  exit 1
fi
NODE_DIR="$(dirname "$NODE_BIN")"
export PATH="$NODE_DIR:$PATH"
hash -r 2>/dev/null || true
echo "==> Usando Node $("$NODE_BIN" -v) ($NODE_BIN)"

${Object.entries(files)
  .map(([p, c]) => heredoc(p, c))
  .join("\n")}
cd "$DIR"
echo "==> Instalando dependencias (Playwright + Chromium). Pode levar alguns minutos..."
"$NODE_DIR/npm" install --silent || npm install --silent

echo ""
echo "==> Pronto! Agora entre com a sua conta do painel:"
echo ""
"$NODE_BIN" farm-agent.mjs login < /dev/tty

echo ""
echo "==> Ligando o agente. Deixe esta janela do Terminal aberta."
echo "    Tudo que voce marcar como 'Rodando' no painel abre aqui automaticamente."
echo ""
exec "$NODE_BIN" farm-agent.mjs watch < /dev/tty
`;
}

export const Route = createFileRoute("/api/public/install-agent")({
  server: {
    handlers: {
      GET: async () =>
        new Response(buildScript(process.env["CAPTCHA_API_KEY"] ?? ""), {
          headers: {
            "content-type": "text/x-shellscript; charset=utf-8",
            "cache-control": "no-store",
          },
        }),
    },
  },
});

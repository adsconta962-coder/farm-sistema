import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ArrowLeft, Building2, Loader2, Star, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/empresas")({
  head: () => ({
    meta: [
      { title: "Meus CNPJs — FARM" },
      {
        name: "description",
        content:
          "Cofre dos CNPJs próprios e dos sócios usados para preencher as informações das BMs sem redigitar.",
      },
      { property: "og:title", content: "Meus CNPJs — FARM" },
      {
        property: "og:description",
        content: "Cadastre uma vez os dados das suas empresas e reutilize no fluxo do agente.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: EmpresasPage,
});

type CompanyRow = {
  id: string;
  cnpj: string;
  legal_name: string | null;
  trade_name: string | null;
  owner_name: string | null;
  email: string | null;
  phone: string | null;
  street: string | null;
  number: string | null;
  complement: string | null;
  district: string | null;
  city: string | null;
  state: string | null;
  zip: string | null;
  website: string | null;
  notes: string | null;
  is_default: boolean;
};

const EMPTY = {
  cnpj: "",
  legal_name: "",
  trade_name: "",
  owner_name: "",
  email: "",
  phone: "",
  street: "",
  number: "",
  complement: "",
  district: "",
  city: "",
  state: "",
  zip: "",
  website: "",
  notes: "",
};

function onlyDigits(v: string) {
  return v.replace(/\D+/g, "");
}

function EmpresasPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [form, setForm] = useState({ ...EMPTY });
  const [lookingUp, setLookingUp] = useState(false);

  useEffect(() => {
    if (!loading && !user) void navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  const { data: companies = [] } = useQuery({
    queryKey: ["own_companies"],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("own_companies")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as CompanyRow[];
    },
  });

  const saveMutation = useMutation({
    mutationFn: async () => {
      const cnpj = onlyDigits(form.cnpj);
      if (cnpj.length !== 14) throw new Error("CNPJ precisa ter 14 dígitos");
      const { error } = await supabase.from("own_companies").upsert(
        {
          user_id: user!.id,
          cnpj,
          legal_name: form.legal_name || null,
          trade_name: form.trade_name || null,
          owner_name: form.owner_name || null,
          email: form.email || null,
          phone: form.phone || null,
          street: form.street || null,
          number: form.number || null,
          complement: form.complement || null,
          district: form.district || null,
          city: form.city || null,
          state: form.state || null,
          zip: form.zip || null,
          website: form.website || null,
          notes: form.notes || null,
        },
        { onConflict: "user_id,cnpj" },
      );
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Empresa salva no cofre");
      setForm({ ...EMPTY });
      void queryClient.invalidateQueries({ queryKey: ["own_companies"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("own_companies").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Empresa removida");
      void queryClient.invalidateQueries({ queryKey: ["own_companies"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const defaultMutation = useMutation({
    mutationFn: async (id: string) => {
      const clear = await supabase
        .from("own_companies")
        .update({ is_default: false })
        .eq("user_id", user!.id);
      if (clear.error) throw clear.error;
      const { error } = await supabase
        .from("own_companies")
        .update({ is_default: true })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Empresa padrão definida");
      void queryClient.invalidateQueries({ queryKey: ["own_companies"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  async function lookupCnpj() {
    const cnpj = onlyDigits(form.cnpj);
    if (cnpj.length !== 14) {
      toast.error("Digite os 14 dígitos do CNPJ");
      return;
    }
    setLookingUp(true);
    try {
      const res = await fetch(`https://brasilapi.com.br/api/cnpj/v1/${cnpj}`);
      if (!res.ok) throw new Error("Não encontrei esse CNPJ");
      const d = (await res.json()) as Record<string, unknown>;
      const s = (k: string) => (typeof d[k] === "string" ? (d[k] as string) : "");
      setForm((f) => ({
        ...f,
        legal_name: s("razao_social") || f.legal_name,
        trade_name: s("nome_fantasia") || f.trade_name,
        email: s("email") || f.email,
        street: [s("descricao_tipo_de_logradouro"), s("logradouro")]
          .filter(Boolean)
          .join(" ")
          .trim() || f.street,
        number: s("numero") || f.number,
        complement: s("complemento") || f.complement,
        district: s("bairro") || f.district,
        city: s("municipio") || f.city,
        state: s("uf") || f.state,
        zip: s("cep") || f.zip,
      }));
      toast.success("Dados do CNPJ preenchidos");
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLookingUp(false);
    }
  }

  const field = (key: keyof typeof EMPTY, label: string, placeholder?: string) => (
    <div className="space-y-1.5">
      <Label htmlFor={key}>{label}</Label>
      <Input
        id={key}
        value={form[key]}
        placeholder={placeholder}
        onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
      />
    </div>
  );

  return (
    <main className="mx-auto max-w-6xl px-4 py-8">
      <div className="mb-6 flex items-center gap-3">
        <Button variant="ghost" size="icon" asChild>
          <Link to="/">
            <ArrowLeft className="size-4" />
          </Link>
        </Button>
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-semibold">
            <Building2 className="size-5" /> Meus CNPJs
          </h1>
          <p className="text-sm text-muted-foreground">
            Cadastre aqui os CNPJs seus e dos sócios. O agente usa esses dados nas BMs sem você
            precisar digitar de novo.
          </p>
        </div>
      </div>

      <section className="rounded-lg border border-border bg-card p-5">
        <div className="grid gap-4 md:grid-cols-3">
          <div className="space-y-1.5 md:col-span-1">
            <Label htmlFor="cnpj">CNPJ</Label>
            <div className="flex gap-2">
              <Input
                id="cnpj"
                value={form.cnpj}
                placeholder="00.000.000/0000-00"
                onChange={(e) => setForm((f) => ({ ...f, cnpj: e.target.value }))}
              />
              <Button variant="outline" onClick={lookupCnpj} disabled={lookingUp}>
                {lookingUp ? <Loader2 className="size-4 animate-spin" /> : "Buscar"}
              </Button>
            </div>
          </div>
          {field("legal_name", "Razão social")}
          {field("trade_name", "Nome fantasia")}
          {field("owner_name", "Responsável")}
          {field("email", "E-mail")}
          {field("phone", "Telefone")}
          {field("street", "Logradouro")}
          {field("number", "Número")}
          {field("complement", "Complemento")}
          {field("district", "Bairro")}
          {field("city", "Cidade")}
          {field("state", "UF", "SP")}
          {field("zip", "CEP")}
          {field("website", "Site", "https://")}
          <div className="space-y-1.5 md:col-span-3">
            <Label htmlFor="notes">Observações</Label>
            <Textarea
              id="notes"
              value={form.notes}
              onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
              placeholder="Ex.: CNPJ do sócio João, usar para BMs de tráfego"
            />
          </div>
        </div>
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="ghost" onClick={() => setForm({ ...EMPTY })}>
            Limpar
          </Button>
          <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending}>
            {saveMutation.isPending && <Loader2 className="mr-2 size-4 animate-spin" />}
            Salvar no cofre
          </Button>
        </div>
      </section>

      <section className="mt-8">
        <h2 className="mb-3 text-lg font-medium">
          Cadastrados <span className="text-muted-foreground">({companies.length})</span>
        </h2>
        {companies.length === 0 ? (
          <p className="rounded-lg border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
            Nenhum CNPJ cadastrado ainda. Preencha o formulário acima.
          </p>
        ) : (
          <ul className="space-y-3">
            {companies.map((c) => (
              <li
                key={c.id}
                className="flex flex-wrap items-start justify-between gap-3 rounded-lg border border-border bg-card p-4"
              >
                <div className="min-w-0">
                  <p className="flex items-center gap-2 font-medium">
                    {c.legal_name || c.trade_name || "Sem nome"}
                    {c.is_default && (
                      <span className="rounded bg-primary/10 px-2 py-0.5 text-xs text-primary">
                        padrão
                      </span>
                    )}
                  </p>
                  <p className="text-sm text-muted-foreground">CNPJ {c.cnpj}</p>
                  <p className="text-sm text-muted-foreground">
                    {[c.street, c.number, c.district, c.city, c.state, c.zip]
                      .filter(Boolean)
                      .join(", ")}
                  </p>
                  {(c.email || c.phone) && (
                    <p className="text-sm text-muted-foreground">
                      {[c.email, c.phone].filter(Boolean).join(" · ")}
                    </p>
                  )}
                  {c.notes && <p className="mt-1 text-sm text-muted-foreground">{c.notes}</p>}
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => defaultMutation.mutate(c.id)}
                    disabled={c.is_default}
                  >
                    <Star className="mr-2 size-4" /> Padrão
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => deleteMutation.mutate(c.id)}>
                    <Trash2 className="size-4" />
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </main>
  );
}

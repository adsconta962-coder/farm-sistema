import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ArrowLeft, Copy, ExternalLink, RefreshCw, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SITE_THEMES, getSiteTheme } from "@/lib/siteThemes";

export const Route = createFileRoute("/sites")({
  head: () => ({
    meta: [
      { title: "Sites institucionais — FARM" },
      {
        name: "description",
        content:
          "Painel dos sites institucionais gerados para verificação de domínio das BMs do Facebook.",
      },
      { property: "og:title", content: "Sites institucionais — FARM" },
      {
        property: "og:description",
        content: "Veja, abra e gerencie os sites criados para verificação de domínio.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SitesPage,
});

type SiteRow = {
  id: string;
  slug: string;
  company_name: string;
  cnpj: string | null;
  email: string | null;
  phone: string | null;
  address: string | null;
  meta_tag: string | null;
  theme: string | null;
  instance_id: string | null;
  updated_at: string;
};

function SitesPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (!loading && !user) void navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  const { data: sites = [], isFetching } = useQuery({
    queryKey: ["company_sites"],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("company_sites")
        .select(
          "id, slug, company_name, cnpj, email, phone, address, meta_tag, theme, instance_id, updated_at",
        )
        .order("updated_at", { ascending: false });
      if (error) throw new Error(error.message);
      return (data ?? []) as SiteRow[];
    },
  });

  const setTheme = useMutation({
    mutationFn: async ({ id, theme }: { id: string; theme: string }) => {
      const { error } = await supabase.from("company_sites").update({ theme }).eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      toast.success("Cor do site atualizada");
      void queryClient.invalidateQueries({ queryKey: ["company_sites"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("company_sites").delete().eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      toast.success("Site removido");
      void queryClient.invalidateQueries({ queryKey: ["company_sites"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const origin = typeof window === "undefined" ? "" : window.location.origin;
  const term = search.trim().toLowerCase();
  const filtered = term
    ? sites.filter((s) =>
        [s.company_name, s.slug, s.cnpj ?? ""].some((v) => v.toLowerCase().includes(term)),
      )
    : sites;

  const copy = (value: string, label: string) => {
    void navigator.clipboard.writeText(value);
    toast.success(`${label} copiado`);
  };

  return (
    <div className="min-h-screen">
      <header className="border-b bg-surface">
        <div className="mx-auto flex max-w-[1400px] flex-wrap items-center justify-between gap-4 px-6 py-5">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Sites institucionais</h1>
            <p className="text-xs text-muted-foreground">
              Páginas geradas para verificação de domínio · {sites.length} no total
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              onClick={() => queryClient.invalidateQueries({ queryKey: ["company_sites"] })}
            >
              <RefreshCw className={`mr-2 size-4 ${isFetching ? "animate-spin" : ""}`} /> Atualizar
            </Button>
            <Button variant="outline" asChild>
              <Link to="/">
                <ArrowLeft className="mr-2 size-4" /> Voltar ao painel
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1400px] px-6 py-8">
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Buscar por empresa, slug ou CNPJ…"
          className="max-w-sm"
        />

        {filtered.length === 0 ? (
          <p className="mt-10 text-sm text-muted-foreground">
            Nenhum site ainda. Use o Cockpit de Verificação Manual no painel para criar um.
          </p>
        ) : (
          <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {filtered.map((site) => {
              const url = `${origin}/s/${site.slug}`;
              return (
                <article key={site.id} className="rounded-lg border bg-surface p-5">
                  <h2 className="truncate text-base font-semibold">{site.company_name}</h2>
                  <p className="mt-1 font-mono text-xs text-muted-foreground">/s/{site.slug}</p>

                  <dl className="mt-4 space-y-1.5 text-xs">
                    {site.cnpj ? (
                      <div className="flex gap-2">
                        <dt className="text-muted-foreground">CNPJ</dt>
                        <dd className="font-mono">{site.cnpj}</dd>
                      </div>
                    ) : null}
                    {site.email ? (
                      <div className="flex gap-2 truncate">
                        <dt className="text-muted-foreground">E-mail</dt>
                        <dd className="truncate">{site.email}</dd>
                      </div>
                    ) : null}
                    {site.phone ? (
                      <div className="flex gap-2">
                        <dt className="text-muted-foreground">Telefone</dt>
                        <dd>{site.phone}</dd>
                      </div>
                    ) : null}
                    <div className="flex gap-2">
                      <dt className="text-muted-foreground">Meta tag</dt>
                      <dd>{site.meta_tag ? "configurada" : "—"}</dd>
                    </div>
                  </dl>

                  <div className="mt-4">
                    <p className="mb-1.5 text-xs text-muted-foreground">
                      Cor: {getSiteTheme(site.theme).label}
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {SITE_THEMES.map((t) => (
                        <button
                          key={t.id}
                          type="button"
                          title={t.label}
                          aria-label={t.label}
                          onClick={() => setTheme.mutate({ id: site.id, theme: t.id })}
                          style={{ backgroundColor: t.marca }}
                          className={`size-5 rounded-full border-2 transition-transform ${
                            (site.theme ?? "azul") === t.id
                              ? "scale-110 border-foreground"
                              : "border-transparent"
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  <div className="mt-4 flex flex-wrap gap-2">
                    <Button size="sm" variant="outline" asChild>
                      <a href={url} target="_blank" rel="noreferrer">
                        <ExternalLink className="mr-2 size-3.5" /> Abrir site
                      </a>
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => copy(url, "Link")}>
                      <Copy className="mr-2 size-3.5" /> Link
                    </Button>
                    {site.meta_tag ? (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => copy(site.meta_tag!, "Meta tag")}
                      >
                        <Copy className="mr-2 size-3.5" /> Meta tag
                      </Button>
                    ) : null}
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-destructive hover:bg-destructive/10"
                      onClick={() => remove.mutate(site.id)}
                    >
                      <Trash2 className="size-3.5" />
                    </Button>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}

import { createFileRoute, notFound } from "@tanstack/react-router";
import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { getSiteTheme } from "@/lib/siteThemes";

const SELECT =
  "slug, company_name, cnpj, email, phone, address, about, meta_tag, theme, legal_name, trade_name, owner_name, opening_date, cnae, legal_nature, company_size, capital, situation, unit_type, street, complement, district, city, state, zip";

const getCompanySite = createServerFn({ method: "GET" })
  .inputValidator((data: { slug: string }) => ({ slug: String(data.slug) }))
  .handler(async ({ data }) => {
    const supabase = createClient<Database>(
      process.env["SUPABASE_URL"]!,
      process.env["SUPABASE_PUBLISHABLE_KEY"]!,
      { auth: { storage: undefined, persistSession: false, autoRefreshToken: false } },
    );
    const { data: site, error } = await supabase
      .from("company_sites")
      .select(SELECT)
      .eq("slug", data.slug)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return site;
  });

export const Route = createFileRoute("/s/$slug")({
  loader: async ({ params }) => {
    const site = await getCompanySite({ data: { slug: params.slug } });
    if (!site) throw notFound();
    return site;
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Indisponível" }, { name: "robots", content: "noindex" }] };
    }
    const name = loaderData.legal_name || loaderData.company_name;
    const local = [loaderData.city, loaderData.state].filter(Boolean).join("/");
    const activity = loaderData.cnae || loaderData.about || "atividades empresariais";
    const description = `${name} — ${activity}${local ? ` em ${local}` : ""}.${
      loaderData.cnpj ? ` CNPJ ${loaderData.cnpj}.` : ""
    }`;
    const verification = loaderData.meta_tag?.match(/content="([^"]+)"/)?.[1] ?? null;
    return {
      meta: [
        { title: name },
        { name: "description", content: description },
        { name: "author", content: name },
        { property: "og:type", content: "business.business" },
        { property: "og:title", content: name },
        { property: "og:description", content: description },
        { property: "og:locale", content: "pt_BR" },
        { name: "twitter:card", content: "summary" },
        ...(loaderData.street
          ? [{ property: "business:contact_data:street_address", content: loaderData.street }]
          : []),
        ...(loaderData.city
          ? [{ property: "business:contact_data:locality", content: loaderData.city }]
          : []),
        ...(loaderData.state
          ? [{ property: "business:contact_data:region", content: loaderData.state }]
          : []),
        ...(loaderData.zip
          ? [{ property: "business:contact_data:postal_code", content: loaderData.zip }]
          : []),
        { property: "business:contact_data:country_name", content: "Brasil" },
        ...(verification
          ? [{ name: "facebook-domain-verification", content: verification }]
          : []),
      ],
    };
  },
  errorComponent: () => (
    <main style={{ display: "grid", minHeight: "100vh", placeItems: "center", padding: 32 }}>
      <p>Não foi possível carregar este site.</p>
    </main>
  ),
  notFoundComponent: () => (
    <main style={{ display: "grid", minHeight: "100vh", placeItems: "center", padding: 32 }}>
      <p>Site não encontrado.</p>
    </main>
  ),
  component: CompanySitePage,
});

function CompanySitePage() {
  const site = Route.useLoaderData();
  const t = getSiteTheme(site.theme);

  const legalName = site.legal_name || site.company_name;
  const tradeName = site.trade_name || site.company_name;
  const activity = site.cnae || site.about || "atividades empresariais";
  const local = [site.city, site.state].filter(Boolean).join("-");
  const fullAddress =
    site.address ||
    [site.street, site.complement, site.district, local ? `${site.city}/${site.state}` : "", site.zip ? `CEP ${site.zip}` : ""]
      .filter(Boolean)
      .join(", ");

  const rows: Array<[string, string]> = [
    ["Razão Social", legalName],
    ["Nome Fantasia", tradeName],
    ["CNPJ", site.cnpj ?? ""],
    ["Data de Abertura", site.opening_date ?? ""],
    ["Atividade Principal (CNAE)", site.cnae ?? ""],
    ["Natureza Jurídica", site.legal_nature ?? ""],
    ["Porte", site.company_size ?? ""],
    ["Capital Social", site.capital ?? ""],
    ["Situação Cadastral", site.situation ?? ""],
    ["Tipo", site.unit_type ?? ""],
    ["E-mail", site.email ?? ""],
    ["Telefone", site.phone ?? ""],
    ["Endereço", fullAddress],
  ].filter(([, v]) => Boolean(v)) as Array<[string, string]>;

  const css = `
:root{--marca:${t.marca};--marca-claro:${t.marcaClaro};--marca-escuro:${t.marcaEscuro};--tinta:#0e1420;--cinza:#475569;--linha:#e2e7f0;--bg:${t.bg};--raio:14px;}
.cs *{margin:0;padding:0;box-sizing:border-box}
.cs{font-family:'DM Sans',Inter,system-ui,sans-serif;color:var(--tinta);background:#fff;line-height:1.7}
.cs a{color:inherit;text-decoration:none}
.cs .container{width:min(960px,92%);margin-inline:auto}
.cs h2.sec-titulo{font-size:clamp(1.5rem,3vw,2rem);font-weight:800;letter-spacing:-.02em;color:var(--marca);margin-bottom:18px}
.cs h3.sub{font-size:1.1rem;font-weight:700;margin:24px 0 10px;color:var(--tinta)}
.cs p{color:var(--cinza);margin-bottom:14px}
.cs .topbar{background:var(--marca-escuro);color:var(--marca-claro);font-size:.82rem}
.cs .topbar .container{display:flex;justify-content:flex-end;align-items:center;height:38px;gap:18px}
.cs .topbar a{font-weight:600;letter-spacing:.04em}
.cs header{background:linear-gradient(135deg,var(--marca),var(--marca-claro));color:#fff;padding:54px 0;text-align:center}
.cs header .selo-logo{width:84px;height:84px;border-radius:50%;background:rgba(255,255,255,.16);border:2px solid rgba(255,255,255,.35);display:grid;place-items:center;margin:0 auto 22px}
.cs header h1{font-size:clamp(1.4rem,3.4vw,2.1rem);font-weight:800;line-height:1.2}
.cs header .cnpj{margin-top:10px;font-size:1rem;font-weight:600;color:#f1f5ff}
.cs .missao{background:var(--bg);border-bottom:1px solid var(--linha)}
.cs .missao .container{padding:54px 0;text-align:center}
.cs .missao .label{display:inline-block;font-size:.8rem;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--marca);margin-bottom:14px}
.cs .missao p{font-size:1.18rem;color:var(--tinta);max-width:760px;margin-inline:auto}
.cs .bloco{padding:64px 0}
.cs .check-list{list-style:none;margin:6px 0 10px;display:grid;gap:10px}
.cs .check-list li{display:flex;gap:11px;align-items:flex-start;color:var(--cinza);font-size:1rem}
.cs .check-list li::before{content:"✔";color:#16a34a;font-weight:800;flex-shrink:0}
.cs .info-card{background:var(--bg);border:1px solid var(--linha);border-radius:var(--raio);padding:8px 28px;margin-top:14px}
.cs .info-row{display:flex;gap:14px;padding:13px 0;border-bottom:1px solid var(--linha);font-size:.98rem;flex-wrap:wrap}
.cs .info-row:last-child{border-bottom:none}
.cs .info-row .k{font-weight:700;color:var(--tinta);min-width:200px}
.cs .info-row .v{color:var(--cinza)}
.cs .fechamento{font-size:1.05rem;font-weight:600;color:var(--marca);text-align:center;margin-top:24px}
.cs .footer-priv{background:#0e1420;color:#c9d1de;padding:60px 0}
.cs .footer-priv h2{color:#fff;font-size:1.5rem;font-weight:800;margin-bottom:22px}
.cs .footer-priv .empresa-resumo{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--raio);padding:10px 26px;margin-bottom:36px}
.cs .footer-priv .empresa-resumo .info-row{border-color:rgba(255,255,255,.1)}
.cs .footer-priv .empresa-resumo .k{color:#fff}
.cs .footer-priv .empresa-resumo .v{color:#a4b0c2}
.cs .footer-priv h3{color:var(--marca-claro);font-size:1.08rem;margin:28px 0 8px}
.cs .footer-priv p,.cs .footer-priv li{color:#a4b0c2;font-size:.95rem}
.cs .footer-priv ul{padding-left:20px;margin-bottom:12px}
.cs .footer-priv li{margin-bottom:6px}
.cs .footer-priv strong{color:#dbe2ec}
.cs .copyright{text-align:center;padding-top:34px;margin-top:34px;border-top:1px solid rgba(255,255,255,.1);font-size:.85rem;color:#7d8798}
@media (max-width:640px){.cs .info-row .k{min-width:100%}.cs .bloco{padding:48px 0}}
`;

  const InfoRows = ({ className }: { className: string }) => (
    <div className={className}>
      {rows.map(([k, v]) => (
        <div className="info-row" key={k}>
          <span className="k">{k}</span>
          <span className="v">{v}</span>
        </div>
      ))}
    </div>
  );

  return (
    <div className="cs">
      <style dangerouslySetInnerHTML={{ __html: css }} />

      <div className="topbar">
        <div className="container">
          <a href="#privacidade">POLÍTICA DE PRIVACIDADE</a>
        </div>
      </div>

      <header>
        <div className="container">
          <div className="selo-logo">
            <svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.6" aria-hidden="true">
              <path d="M4 19.5A2.5 2.5 0 016.5 17H20M4 19.5A2.5 2.5 0 016.5 22H20V4a2 2 0 00-2-2H6.5A2.5 2.5 0 004 4.5v15z" />
            </svg>
          </div>
          <h1>{legalName}</h1>
          {site.cnpj ? <div className="cnpj">CNPJ {site.cnpj}</div> : null}
        </div>
      </header>

      <section className="missao">
        <div className="container">
          <span className="label">Nossa Missão</span>
          <p>
            Oferecer {activity} com variedade, preço justo e bom atendimento
            {site.city ? `, atendendo ${site.city}/${site.state} e região` : ""}.
          </p>
        </div>
      </section>

      <section className="bloco">
        <div className="container">
          <h2 className="sec-titulo">Quem Somos?</h2>
          <p>
            A <strong>{legalName}</strong>
            {tradeName && tradeName !== legalName ? ` (${tradeName})` : ""}
            {site.cnpj ? (
              <>
                , registrada sob o CNPJ <strong>{site.cnpj}</strong>
              </>
            ) : null}
            {site.opening_date ? (
              <>
                {" "}
                e fundada em <strong>{site.opening_date}</strong>
              </>
            ) : null}
            {site.district || site.city ? (
              <>
                , está localizada {site.district ? `no bairro ${site.district}, ` : ""}
                em {site.city}
                {site.state ? `-${site.state}` : ""}
              </>
            ) : null}{" "}
            e atua com {activity}.
          </p>
          <p>
            Nosso compromisso é sempre atender com atenção, qualidade e transparência, construindo
            relações de confiança com cada cliente.
          </p>

          <h3 className="sub">Serviços/Produtos Disponíveis:</h3>
          <ul className="check-list">
            <li>{activity}</li>
          </ul>

          <h3 className="sub">Informações da Empresa:</h3>
          <InfoRows className="info-card" />

          <p className="fechamento">Variedade e bom atendimento para o seu dia a dia.</p>
        </div>
      </section>

      <section className="footer-priv" id="privacidade">
        <div className="container">
          <h2>Rodapé &amp; Política de Privacidade</h2>
          <InfoRows className="empresa-resumo" />

          <h2 style={{ fontSize: "1.3rem" }}>Política de Privacidade</h2>
          <p>
            <strong>{legalName}</strong>
            {site.cnpj ? ` — CNPJ ${site.cnpj}` : ""}
            {fullAddress ? ` — ${fullAddress}` : ""}.
          </p>

          <h3>1. Finalidade</h3>
          <p>
            Esta política descreve como coletamos, utilizamos, armazenamos e protegemos os dados
            pessoais dos clientes, parceiros e visitantes que interagem conosco, em conformidade com
            a Lei Geral de Proteção de Dados (Lei nº 13.709/2018 — LGPD).
          </p>

          <h3>2. Dados Coletados</h3>
          <ul>
            <li>
              <strong>Informações fornecidas voluntariamente:</strong> nome, dados de contato e
              informações necessárias para negociações comerciais.
            </li>
            <li>
              <strong>Dados técnicos e de navegação:</strong> endereço IP, tipo de dispositivo e
              interações, quando aplicável.
            </li>
          </ul>

          <h3>3. Uso dos Dados</h3>
          <ul>
            <li>Prestação dos serviços oferecidos;</li>
            <li>Comunicação relacionada a negócios e atendimento;</li>
            <li>Cumprimento de obrigações legais.</li>
          </ul>

          <h3>4. Compartilhamento de Dados</h3>
          <p>
            Não comercializamos dados pessoais. Compartilhamos apenas com parceiros técnicos
            essenciais à operação e autoridades legais, quando exigido por lei.
          </p>

          <h3>5. Direitos do Titular (LGPD)</h3>
          <ul>
            <li>Acessar, corrigir ou excluir seus dados;</li>
            <li>Revogar consentimento e solicitar portabilidade.</li>
          </ul>

          <h3>6. Segurança e Armazenamento</h3>
          <p>
            Adotamos medidas técnicas para proteger os dados contra acesso não autorizado, mantendo-os
            apenas pelo tempo necessário.
          </p>

          <h3>7. Alterações e Contato</h3>
          <p>
            Esta política pode ser atualizada periodicamente. Dúvidas podem ser encaminhadas pelos
            nossos canais oficiais.
          </p>

          <div className="copyright">
            © {new Date().getFullYear()} {legalName}. Todos os direitos reservados.
          </div>
        </div>
      </section>
    </div>
  );
}

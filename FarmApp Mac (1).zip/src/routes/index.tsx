import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Building2,
  Check,

  Copy,
  Globe,
  LayoutGrid,
  List,
  LogOut,
  RefreshCw,
  ScanSearch,
  Search,
  Terminal,
  Upload,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ImportDialog } from "@/components/farm/ImportDialog";
import { InstanceFormDialog, type InstanceDraft } from "@/components/farm/InstanceFormDialog";
import { InstancesTable } from "@/components/farm/InstancesTable";
import { AgentDialog } from "@/components/farm/AgentDialog";
import { ManualVerificationDialog } from "@/components/farm/ManualVerificationDialog";
import { StatsGrid } from "@/components/farm/StatsGrid";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import type { Instance, InstanceStatus } from "@/lib/farm";
import { STATUS_META, initials, progressPercent, relativeTime } from "@/lib/farm";
import { getDomainVerificationTokens } from "@/lib/verification.functions";

export const Route = createFileRoute("/")({
  loader: async () => {
    try {
      return await getDomainVerificationTokens();
    } catch {
      return { tokens: [] as string[] };
    }
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: "FARM — Painel de instâncias e automação de perfis" },
      {
        name: "description",
        content:
          "Painel FARM na web: gerencie instâncias, proxies, perfis e progresso das etapas em qualquer computador, incluindo MacBook.",
      },
      { property: "og:title", content: "FARM — Painel de instâncias" },
      {
        property: "og:description",
        content: "Gerencie instâncias, proxies e perfis do FARM direto do navegador.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      // verificação de domínio do Meta (precisa ficar no domínio raiz)
      ...(loaderData?.tokens ?? []).map((content: string) => ({
        name: "facebook-domain-verification",
        content,
      })),
    ],
  }),
  errorComponent: () => <Dashboard />,
  notFoundComponent: () => <Dashboard />,
  component: Dashboard,
});

function Dashboard() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [search, setSearch] = useState("");
  const [view, setView] = useState<"grid" | "list">("list");
  const [selected, setSelected] = useState<string[]>([]);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Instance | null>(null);
  const [importOpen, setImportOpen] = useState(false);
  const [verifyOpen, setVerifyOpen] = useState(false);
  const [agentOpen, setAgentOpen] = useState(false);
  const [ip, setIp] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!loading && !user) void navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  const loadIp = () => {
    fetch("https://api.ipify.org?format=json")
      .then((r) => r.json())
      .then((d: { ip: string }) => setIp(d.ip))
      .catch(() => setIp(null));
  };
  useEffect(loadIp, []);

  const instancesQuery = useQuery({
    queryKey: ["instances", user?.id],
    enabled: Boolean(user),
    queryFn: async () => {
      const { data, error } = await supabase
        .from("instances")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as Instance[];
    },
  });

  const instances = instancesQuery.data ?? [];

  const invalidate = () =>
    queryClient.invalidateQueries({ queryKey: ["instances", user?.id] });

  const saveMutation = useMutation({
    mutationFn: async (draft: InstanceDraft) => {
      if (editing) {
        const { error } = await supabase
          .from("instances")
          .update({ ...draft, last_activity_at: new Date().toISOString() })
          .eq("id", editing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("instances")
          .insert({ ...draft, user_id: user!.id });
        if (error) throw error;
      }
    },
    onSuccess: async () => {
      await invalidate();
      setFormOpen(false);
      setEditing(null);
      toast.success(editing ? "Instância atualizada" : "Instância criada");
    },
    onError: (error: Error) => toast.error("Não foi possível salvar", { description: error.message }),
  });

  const statusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: InstanceStatus }) => {
      const current = instances.find((instance) => instance.id === id);
      const isSmsResume =
        status === "rodando" &&
        current?.status === "analise_pendente" &&
        /SMS/i.test(current.notes ?? "");
      const patch =
        status === "rodando"
          ? {
              status,
              ...(isSmsResume ? {} : { step: 0 }),
              notes: isSmsResume
                ? "SMS recebido informado no painel. Agente continuando o fluxo."
                : (current?.notes ?? null),
              last_activity_at: new Date().toISOString(),
            }
          : { status, last_activity_at: new Date().toISOString() };
      const { error } = await supabase
        .from("instances")
        .update(patch)
        .eq("id", id);
      if (error) throw error;
      return { status, isSmsResume };
    },
    onSuccess: async ({ status, isSmsResume }) => {
      await invalidate();
      if (status === "rodando") {
        toast.success(isSmsResume ? "SMS recebido — fluxo continuando" : "Instância enviada para execução", {
          description: isSmsResume
            ? "Agora o agente seguirá para domínio, meta tag, verificação e WABA."
            : "Mantenha o FARM Agent aberto no Terminal do seu Mac.",
        });
      }
    },
    onError: (error: Error) => toast.error("Falha ao atualizar status", { description: error.message }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (ids: string[]) => {
      const { error } = await supabase.from("instances").delete().in("id", ids);
      if (error) throw error;
    },
    onSuccess: async () => {
      await invalidate();
      setSelected([]);
      toast.success("Instância(s) excluída(s)");
    },
  });

  const importMutation = useMutation({
    mutationFn: async (
      rows: { name: string; profile_email: string | null; profile_password: string | null; proxy: string | null }[],
    ) => {
      const { error } = await supabase
        .from("instances")
        .insert(rows.map((row) => ({ ...row, user_id: user!.id })));
      if (error) throw error;
    },
    onSuccess: async () => {
      await invalidate();
      setImportOpen(false);
      toast.success("Importação concluída");
    },
    onError: (error: Error) => toast.error("Falha na importação", { description: error.message }),
  });

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return instances;
    return instances.filter((i) =>
      [i.name, i.short_id, i.profile_email ?? "", i.proxy ?? "", STATUS_META[i.status].label]
        .join(" ")
        .toLowerCase()
        .includes(term),
    );
  }, [instances, search]);

  const copyIp = () => {
    if (!ip) return;
    void navigator.clipboard.writeText(ip);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  if (loading || !user) {
    return (
      <div className="flex min-h-screen items-center justify-center text-sm text-muted-foreground">
        Carregando…
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <header className="border-b bg-surface">
        <div className="mx-auto flex max-w-[1400px] flex-wrap items-center justify-between gap-4 px-6 py-5">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">FARM</h1>
            <p className="text-xs text-muted-foreground">v1.0.3 · web</p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-2 rounded-full border bg-background px-3 py-1.5 text-sm">
              <Globe className="size-4 text-muted-foreground" />
              <span className="text-muted-foreground">IP atual</span>
              <span className="font-mono font-medium">{ip ?? "—"}</span>
              <button
                type="button"
                onClick={copyIp}
                aria-label="Copiar IP"
                className="text-muted-foreground hover:text-foreground"
              >
                {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
              </button>
              <button
                type="button"
                onClick={loadIp}
                aria-label="Atualizar IP"
                className="text-muted-foreground hover:text-foreground"
              >
                <RefreshCw className="size-4" />
              </button>
            </div>

            <Button variant="outline" asChild>
              <Link to="/sites">
                <Globe className="mr-2 size-4" /> Sites
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link to="/empresas">
                <Building2 className="mr-2 size-4" /> Meus CNPJs
              </Link>
            </Button>

            <Button variant="outline" onClick={() => setAgentOpen(true)}>
              <Terminal className="mr-2 size-4" /> Agente Mac
            </Button>
            <Button variant="outline" onClick={() => setVerifyOpen(true)}>
              <ScanSearch className="mr-2 size-4" /> Verificação Manual
            </Button>


            <Button variant="outline" onClick={() => setImportOpen(true)}>
              <Upload className="mr-2 size-4" /> Importar
            </Button>
            <Button
              onClick={() => {
                setEditing(null);
                setFormOpen(true);
              }}
            >
              + Nova Instância
            </Button>
            <button
              type="button"
              aria-label="Sair"
              onClick={async () => {
                await supabase.auth.signOut();
                void navigate({ to: "/auth" });
              }}
              className="inline-flex size-9 items-center justify-center rounded-md text-destructive hover:bg-destructive/10"
            >
              <LogOut className="size-4" />
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1400px] px-6 py-8">
        <StatsGrid instances={instances} />

        <section className="mt-10">
          <h2 className="text-xl font-semibold tracking-tight">Instâncias</h2>
          <p className="text-sm text-muted-foreground">
            {filtered.length} de {instances.length} instâncias
          </p>

          <div className="mt-4 flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Buscar instâncias..."
                className="h-11 pl-9"
              />
            </div>
            <div className="flex items-center gap-1 rounded-lg border p-1">
              <button
                type="button"
                aria-label="Ver em cartões"
                onClick={() => setView("grid")}
                className={`inline-flex size-8 items-center justify-center rounded-md ${view === "grid" ? "bg-muted text-foreground" : "text-muted-foreground"}`}
              >
                <LayoutGrid className="size-4" />
              </button>
              <button
                type="button"
                aria-label="Ver em lista"
                onClick={() => setView("list")}
                className={`inline-flex size-8 items-center justify-center rounded-md ${view === "list" ? "bg-muted text-foreground" : "text-muted-foreground"}`}
              >
                <List className="size-4" />
              </button>
            </div>
          </div>

          {selected.length > 0 && (
            <div className="mt-3 flex items-center gap-3 rounded-lg border bg-accent/40 px-4 py-2 text-sm">
              <span>{selected.length} selecionada(s)</span>
              <Button
                size="sm"
                variant="outline"
                onClick={() => statusMutation.mutate({ id: selected[0]!, status: "rodando" })}
              >
                Iniciar primeira
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="text-destructive"
                onClick={() => deleteMutation.mutate(selected)}
              >
                Excluir selecionadas
              </Button>
            </div>
          )}

          <div className="mt-4">
            {instancesQuery.isLoading ? (
              <div className="panel px-6 py-16 text-center text-sm text-muted-foreground">
                Carregando instâncias…
              </div>
            ) : view === "list" ? (
              <InstancesTable
                instances={filtered}
                selected={selected}
                onToggle={(id) =>
                  setSelected((prev) =>
                    prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
                  )
                }
                onToggleAll={() =>
                  setSelected((prev) =>
                    prev.length === filtered.length ? [] : filtered.map((i) => i.id),
                  )
                }
                onEdit={(instance) => {
                  setEditing(instance);
                  setFormOpen(true);
                }}
                onStatus={(instance, status) =>
                  statusMutation.mutate({ id: instance.id, status })
                }
                onDelete={(instance) => deleteMutation.mutate([instance.id])}
              />
            ) : (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {filtered.map((instance) => {
                  const meta = STATUS_META[instance.status];
                  return (
                    <button
                      key={instance.id}
                      type="button"
                      onClick={() => {
                        setEditing(instance);
                        setFormOpen(true);
                      }}
                      className="panel p-4 text-left transition-shadow hover:shadow-raise"
                    >
                      <div className="flex items-center gap-3">
                        <div className="flex size-9 items-center justify-center rounded-full bg-accent text-xs font-semibold text-accent-foreground">
                          {initials(instance.name)}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="truncate font-medium">{instance.name}</div>
                          <div className="font-mono text-xs text-muted-foreground">
                            {instance.short_id}
                          </div>
                        </div>
                      </div>
                      <div className="mt-3 flex items-center justify-between">
                        <span
                          className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${meta.chip}`}
                        >
                          <span className={`size-1.5 rounded-full ${meta.dot}`} />
                          {meta.label}
                        </span>
                        <span className="font-mono text-xs text-muted-foreground">
                          {progressPercent(instance.step, instance.total_steps)}%
                        </span>
                      </div>
                      <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-muted">
                        <div
                          className="h-full rounded-full bg-primary"
                          style={{
                            width: `${progressPercent(instance.step, instance.total_steps)}%`,
                          }}
                        />
                      </div>
                      <div className="mt-3 text-xs text-muted-foreground">
                        {relativeTime(instance.last_activity_at)}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </section>

        <p className="mt-8 text-xs text-muted-foreground">
          O agente local (terminal) lê estas instâncias e abre os perfis no seu computador — use o
          botão de terminal em cada linha para copiar o comando de execução.
        </p>
      </main>

      <InstanceFormDialog
        open={formOpen}
        onOpenChange={(open) => {
          setFormOpen(open);
          if (!open) setEditing(null);
        }}
        instance={editing}
        pending={saveMutation.isPending}
        onSubmit={(draft) => saveMutation.mutate(draft)}
      />
      <ImportDialog
        open={importOpen}
        onOpenChange={setImportOpen}
        pending={importMutation.isPending}
        onImport={(rows) => importMutation.mutate(rows)}
      />
      <ManualVerificationDialog open={verifyOpen} onOpenChange={setVerifyOpen} />
      <AgentDialog open={agentOpen} onOpenChange={setAgentOpen} />
    </div>
  );
}

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      company_sites: {
        Row: {
          about: string | null
          address: string | null
          capital: string | null
          city: string | null
          cnae: string | null
          cnpj: string | null
          company_name: string
          company_size: string | null
          complement: string | null
          created_at: string
          district: string | null
          email: string | null
          id: string
          instance_id: string | null
          legal_name: string | null
          legal_nature: string | null
          meta_tag: string | null
          opening_date: string | null
          owner_name: string | null
          phone: string | null
          situation: string | null
          slug: string
          state: string | null
          street: string | null
          theme: string
          trade_name: string | null
          unit_type: string | null
          updated_at: string
          user_id: string
          zip: string | null
        }
        Insert: {
          about?: string | null
          address?: string | null
          capital?: string | null
          city?: string | null
          cnae?: string | null
          cnpj?: string | null
          company_name: string
          company_size?: string | null
          complement?: string | null
          created_at?: string
          district?: string | null
          email?: string | null
          id?: string
          instance_id?: string | null
          legal_name?: string | null
          legal_nature?: string | null
          meta_tag?: string | null
          opening_date?: string | null
          owner_name?: string | null
          phone?: string | null
          situation?: string | null
          slug: string
          state?: string | null
          street?: string | null
          theme?: string
          trade_name?: string | null
          unit_type?: string | null
          updated_at?: string
          user_id: string
          zip?: string | null
        }
        Update: {
          about?: string | null
          address?: string | null
          capital?: string | null
          city?: string | null
          cnae?: string | null
          cnpj?: string | null
          company_name?: string
          company_size?: string | null
          complement?: string | null
          created_at?: string
          district?: string | null
          email?: string | null
          id?: string
          instance_id?: string | null
          legal_name?: string | null
          legal_nature?: string | null
          meta_tag?: string | null
          opening_date?: string | null
          owner_name?: string | null
          phone?: string | null
          situation?: string | null
          slug?: string
          state?: string | null
          street?: string | null
          theme?: string
          trade_name?: string | null
          unit_type?: string | null
          updated_at?: string
          user_id?: string
          zip?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "company_sites_instance_id_fkey"
            columns: ["instance_id"]
            isOneToOne: false
            referencedRelation: "instances"
            referencedColumns: ["id"]
          },
        ]
      }
      instances: {
        Row: {
          auto_allocate: boolean
          bm_id: string | null
          cnpj: string | null
          company_name: string | null
          company_site: string | null
          created_at: string
          direct_bm: boolean
          id: string
          invert_flow: boolean
          last_activity_at: string
          meta_tag: string | null
          name: string
          notes: string | null
          profile_2fa: string | null
          profile_email: string | null
          profile_password: string | null
          proxy: string | null
          proxy_ip: string | null
          short_id: string
          site_theme: string
          sms_number: string | null
          soak_mode: boolean
          status: Database["public"]["Enums"]["instance_status"]
          step: number
          tags: string[]
          total_steps: number
          updated_at: string
          user_id: string
          waba_created: boolean
        }
        Insert: {
          auto_allocate?: boolean
          bm_id?: string | null
          cnpj?: string | null
          company_name?: string | null
          company_site?: string | null
          created_at?: string
          direct_bm?: boolean
          id?: string
          invert_flow?: boolean
          last_activity_at?: string
          meta_tag?: string | null
          name: string
          notes?: string | null
          profile_2fa?: string | null
          profile_email?: string | null
          profile_password?: string | null
          proxy?: string | null
          proxy_ip?: string | null
          short_id?: string
          site_theme?: string
          sms_number?: string | null
          soak_mode?: boolean
          status?: Database["public"]["Enums"]["instance_status"]
          step?: number
          tags?: string[]
          total_steps?: number
          updated_at?: string
          user_id: string
          waba_created?: boolean
        }
        Update: {
          auto_allocate?: boolean
          bm_id?: string | null
          cnpj?: string | null
          company_name?: string | null
          company_site?: string | null
          created_at?: string
          direct_bm?: boolean
          id?: string
          invert_flow?: boolean
          last_activity_at?: string
          meta_tag?: string | null
          name?: string
          notes?: string | null
          profile_2fa?: string | null
          profile_email?: string | null
          profile_password?: string | null
          proxy?: string | null
          proxy_ip?: string | null
          short_id?: string
          site_theme?: string
          sms_number?: string | null
          soak_mode?: boolean
          status?: Database["public"]["Enums"]["instance_status"]
          step?: number
          tags?: string[]
          total_steps?: number
          updated_at?: string
          user_id?: string
          waba_created?: boolean
        }
        Relationships: []
      }
      own_companies: {
        Row: {
          city: string | null
          cnpj: string
          complement: string | null
          created_at: string
          district: string | null
          email: string | null
          id: string
          is_default: boolean
          legal_name: string | null
          notes: string | null
          number: string | null
          owner_name: string | null
          phone: string | null
          state: string | null
          street: string | null
          trade_name: string | null
          updated_at: string
          user_id: string
          website: string | null
          zip: string | null
        }
        Insert: {
          city?: string | null
          cnpj: string
          complement?: string | null
          created_at?: string
          district?: string | null
          email?: string | null
          id?: string
          is_default?: boolean
          legal_name?: string | null
          notes?: string | null
          number?: string | null
          owner_name?: string | null
          phone?: string | null
          state?: string | null
          street?: string | null
          trade_name?: string | null
          updated_at?: string
          user_id: string
          website?: string | null
          zip?: string | null
        }
        Update: {
          city?: string | null
          cnpj?: string
          complement?: string | null
          created_at?: string
          district?: string | null
          email?: string | null
          id?: string
          is_default?: boolean
          legal_name?: string | null
          notes?: string | null
          number?: string | null
          owner_name?: string | null
          phone?: string | null
          state?: string | null
          street?: string | null
          trade_name?: string | null
          updated_at?: string
          user_id?: string
          website?: string | null
          zip?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string | null
          id: string
        }
        Insert: {
          created_at?: string
          display_name?: string | null
          id: string
        }
        Update: {
          created_at?: string
          display_name?: string | null
          id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      instance_status:
        | "rodando"
        | "parado"
        | "analise_pendente"
        | "restricao"
        | "molho"
        | "erro"
        | "concluido"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      instance_status: [
        "rodando",
        "parado",
        "analise_pendente",
        "restricao",
        "molho",
        "erro",
        "concluido",
      ],
    },
  },
} as const

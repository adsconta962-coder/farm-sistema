/**
 * Rotina FARM BM — fluxo identico ao software original (analisado frame a frame
 * da gravacao): login do perfil do Facebook (com 2FA), criacao do portfolio
 * empresarial, preenchimento dos detalhes da empresa via CNPJ, publicacao do
 * site institucional, dominio + meta tag + verificacao, WABA e envio da
 * verificacao da empresa.
 *
 * Dados por instancia: profile_email, profile_password, profile_2fa (opcional),
 * cnpj, proxy. Config em agent/.env: FARM_SMS_* e FARM_PANEL_URL.
 */
import { captchaEnabled, solvePageCaptcha } from "../lib/captcha.mjs";
import {
  lookupCnpj,
  onlyDigits,
  formatCnpj,

  scrapeCnpjBiz,
  fetchFromReceita,
} from "../lib/cnpj.mjs";

import { rentNumber, waitCode, finishNumber, smsEnabled } from "../lib/sms.mjs";
import { publishCompanySite, saveMetaTag, PANEL_URL } from "../lib/site.mjs";
import {
  updateInstance,
  waitForInstanceStatus,
  claimOwnCompany,
  ownCompanyToCompany,
} from "../lib/api.mjs";
import { totp } from "../lib/totp.mjs";
import { humanClick, humanType, humanScan, think, settle, sleep } from "../lib/human.mjs";

const FB_URL = "https://www.facebook.com/";
const BM_LOGIN =
  "https://business.facebook.com/business/loginpage/?login_options[0]=FB&login_options[1]=IG";
const BM_LATEST = "https://business.facebook.com/latest";
const pause = (ms) => sleep(ms);

// O Meta so aceita DOMINIO RAIZ (ex.: macbook-farm-app.lovable.app).
// Nunca "https://", nunca caminho "/s/slug", nunca host de preview.
const ROOT_DOMAIN = new URL(PANEL_URL).hostname;
function rootDomain() {
  return ROOT_DOMAIN;
}


// --- Progresso persistido no painel (tags da instancia) --------------------
// Assim, se a rotina parar no meio, ao clicar em Iniciar de novo ela pula
// tudo que ja foi concluido em vez de refazer/duplicar informacoes.
const doneTag = (key) => `feito:${key}`;
function isDone(instance, key) {
  return (instance.tags ?? []).includes(doneTag(key));
}
async function markDone(instance, key) {
  const tag = doneTag(key);
  const tags = instance.tags ?? [];
  if (tags.includes(tag)) return;
  instance.tags = [...tags, tag];
  await updateInstance(instance.id, { tags: instance.tags });
}


async function clickAny(page, texts, timeout = 8000) {
  for (const t of texts) {
    const rx = new RegExp(t, "i");
    for (const loc of [
      page.getByRole("button", { name: rx }).first(),
      page.getByRole("link", { name: rx }).first(),
      page.getByText(rx).first(),
    ]) {
      if (await loc.count().catch(() => 0)) {
        await humanClick(page, loc, timeout);
        return true;
      }
    }
  }
  return false;
}

async function fillLabel(page, labels, value, { onlyIfEmpty = false } = {}) {
  if (!value) return false;
  for (const label of labels) {
    const rx = new RegExp(label, "i");
    for (const loc of [
      page.getByLabel(rx).first(),
      page.getByPlaceholder(rx).first(),
      page.locator(`input[aria-label*="${label}" i]`).first(),
    ]) {
      if (await loc.count().catch(() => 0)) {
        if (onlyIfEmpty) {
          const cur = await loc.inputValue().catch(() => "");
          if (cur && cur.trim()) return true;
        }
        await humanType(page, loc, value, { clear: true });
        return true;
      }
    }
  }
  return false;
}



/** Fecha os popups/tours do Facebook ("Lembrar senha", "Avancar", onboarding). */
async function closePopups(page, log) {
  // qualquer captcha na tela (Facebook usa FunCaptcha/Arkose) e resolvido por API
  try {
    if (captchaEnabled) {
      const solved = await solvePageCaptcha(page, log);
      if (solved) await pause(2500);
    }
  } catch (error) {
    log?.(`captcha: ${error.message}`);
  }

  const closed = await clickAny(page, [
    "Agora não",
    "Not now",
    "^OK$",
    "Avançar",
    "Concluir",
    "Fechar",
    "Dispensar",
  ], 2500);
  if (closed) log?.("popup fechado");
  for (const sel of ['div[aria-label="Fechar"]', 'div[aria-label="Close"]']) {
    const x = page.locator(sel).first();
    if (await x.count().catch(() => 0)) await x.click({ timeout: 2000 }).catch(() => {});
  }
}

function businessIdFrom(url) {
  return new URL(url).searchParams.get("business_id") ?? null;
}

/** Estamos numa tela de 2FA / checkpoint? */
function isTwoFactorUrl(page) {
  return /two_step_verification|two_factor|checkpoint|login\/device|authentication/i.test(
    page.url(),
  );
}

/**
 * Campo de codigo 2FA. Procura na pagina e dentro de iframes; se a URL for de
 * 2FA, aceita qualquer input de texto visivel (o campo "Code" do Facebook nao
 * tem name/aria previsivel).
 */
async function findCodeField(page) {
  const selectors = [
    'input[name="approvals_code"]',
    'input[name="code"]',
    'input[id*="approvals_code" i]',
    'input[aria-label*="ódigo" i]',
    'input[aria-label*="code" i]',
    'input[placeholder*="ódigo" i]',
    'input[placeholder*="code" i]',
    'input[autocomplete="one-time-code"]',
    'input[inputmode="numeric"]',
    'input[type="tel"]',
  ];
  const roots = [page, ...page.frames().filter((f) => f !== page.mainFrame())];
  for (const root of roots) {
    for (const sel of selectors) {
      const loc = root.locator(sel).first();
      if (await loc.isVisible({ timeout: 500 }).catch(() => false)) return loc;
    }
  }
  if (isTwoFactorUrl(page)) {
    for (const root of roots) {
      const loc = root.locator('input[type="text"], input:not([type])').first();
      if (await loc.isVisible({ timeout: 500 }).catch(() => false)) return loc;
    }
  }
  return null;
}

async function codeFieldPresent(page) {
  return Boolean(await findCodeField(page));
}

/**
 * Preenche o 2FA automaticamente (mesmo codigo que o 2fa.cn geraria, mas local).
 * Espera a tela aparecer, gera o TOTP na hora e tenta ate 4 codigos novos.
 */
async function handle2fa(page, instance, log) {
  // espera ate ~90s a tela de 2FA (ela pode aparecer depois de redirects)
  let field = null;
  for (let i = 0; i < 30; i++) {
    field = await findCodeField(page);
    if (field) break;
    // se nao esta em tela de 2FA e ja passou 30s, desiste
    if (!isTwoFactorUrl(page) && i > 10) break;
    await sleep(3000);
  }
  if (!field) return false;

  log(`tela de 2FA detectada (${page.url().slice(0, 80)})`);
  if (!instance.profile_2fa) {
    log("Tela de 2FA detectada mas o perfil nao tem segredo 2FA no painel — corrija manualmente.");
    return false;
  }

  for (let attempt = 1; attempt <= 4; attempt++) {
    const f = await findCodeField(page);
    if (!f) break;
    const code = totp(instance.profile_2fa);
    log(`2FA automatico (tentativa ${attempt}): ${code}`);
    await humanType(page, f, code, { clear: true });
    await think(900, 1800);
    const clicked = await clickAny(page, ["Continuar", "Continue", "Enviar", "Submit", "Avançar"]);
    if (!clicked) await page.keyboard.press("Enter").catch(() => {});
    await page.waitForLoadState("domcontentloaded").catch(() => {});
    await settle(7000, 11000);
    if (!(await codeFieldPresent(page))) {

      log("2FA aceito");
      // "Salvar navegador" / "Trust this device"
      await clickAny(page, [
        "Confiar neste dispositivo",
        "Trust this device",
        "Salvar navegador",
        "Save browser",
        "Continuar",
        "Continue",
      ]).catch(() => {});
      await settle(4000, 7000);
      return true;
    }
    log("codigo recusado — aguardando novo codigo (30s)");
    await sleep(31000);
  }
  log("2FA nao concluido — janela aberta para correcao manual.");
  return false;
}

const steps = [

  {
    name: "Abrir perfil do Facebook",
    async run({ page, log }) {
      await page.goto(FB_URL, { waitUntil: "domcontentloaded" });
      await settle(3500, 6000);
      await humanScan(page);
      await closePopups(page, log);
    },
  },
  {
    name: "Login do perfil + 2FA",
    async run({ page, instance, log }) {
      const emailField = page.locator('input[name="email"], input[type="email"]').first();
      if (!(await emailField.count())) {
        log("perfil ja logado (sessao do perfil persistente)");
        await closePopups(page, log);
        return;
      }
      if (!instance.profile_email || !instance.profile_password) {
        throw new Error("Instancia sem e-mail/senha do Facebook no painel");
      }
      log(`logando com ${instance.profile_email} (digitacao humana)`);
      await humanType(page, emailField, instance.profile_email);
      await think(1200, 2600);
      const passField = page.locator('input[name="pass"], input[type="password"]').first();
      await humanType(page, passField, instance.profile_password);
      await think(1500, 3200);
      const loginBtn = page
        .locator('button[name="login"], button[type="submit"]')
        .first();
      if (await loginBtn.count().catch(() => 0)) {
        await humanClick(page, loginBtn);
      } else {
        await page.keyboard.press("Enter");
      }
      await page.waitForLoadState("domcontentloaded").catch(() => {});
      await settle(7000, 11000);

      // Checkpoint 2FA: "Go to your authentication app" / "app de autenticacao"
      await handle2fa(page, instance, log);


      await closePopups(page, log);

      // Se ainda houver campo de senha / codigo, algo deu errado (senha invalida,
      // checkpoint, captcha). NAO fechamos nada: esperamos voce corrigir manual.
      let avisou = false;
      while (
        (await page.locator('input[name="pass"]').count().catch(() => 0)) ||
        (await codeFieldPresent(page))
      ) {
        // se voltou a aparecer tela de codigo, tenta o 2FA automatico de novo
        if (await codeFieldPresent(page)) {
          const ok = await handle2fa(page, instance, log);
          if (ok) continue;
        }
        if (!avisou) {
          log(
            "LOGIN NAO CONCLUIDO (senha invalida / checkpoint / 2FA). Janela aberta — corrija manualmente no Chromium; o agente continua sozinho depois."
          );
          avisou = true;
        }
        await sleep(5000);
      }
      await closePopups(page, log);
      log("perfil logado");
    },
  },


  {
    name: "Consultar CNPJ da empresa",
    async run({ instance, context, log, state }) {
      let digits = onlyDigits(instance.cnpj ?? "");
      let vaultRow = null;

      // 1) Cofre "Meus CNPJs" do painel: sempre a primeira opcao.
      try {
        vaultRow = await claimOwnCompany(instance);
      } catch (error) {
        log(`cofre de CNPJs indisponivel: ${error.message}`);
      }
      if (vaultRow) {
        digits = onlyDigits(vaultRow.cnpj);
        log(`Usando CNPJ do seu cofre: ${formatCnpj(digits)} — ${vaultRow.legal_name || ""}`);
      } else if (digits.length !== 14) {
        throw new Error(
          "Nenhum CNPJ cadastrado. Abra o painel em Meus CNPJs e cadastre o seu (ou dos socios) antes de rodar."
        );
      }
      if (onlyDigits(instance.cnpj ?? "") !== digits) {
        await updateInstance(instance.id, { cnpj: formatCnpj(digits) });
      }
      state.cnpjDigits = digits;

      // 2) Enriquecer com os documentos oficiais (mostrando na tela).
      const attempts = [
        ["Receita Federal (documento oficial)", () => fetchFromReceita(context, digits, log)],
        ["cnpj.biz (documento na tela)", () => scrapeCnpjBiz(context, digits, log)],
        ["API publica de CNPJ", () => lookupCnpj(digits)],
      ];

      for (const [source, attempt] of attempts) {
        try {
          log(`Consultando: ${source}`);
          state.company = await attempt();
          if (state.company?.legalName) {
            state.companySource = source;
            break;
          }
        } catch (error) {
          log(`fonte de CNPJ falhou (${source}): ${error.message}`);
        }
      }
      // 3) O cofre preenche o que os documentos nao trouxeram (e vira o plano B
      //    se nenhuma consulta responder) — assim o passo nunca trave.
      const vault = ownCompanyToCompany(vaultRow);
      if (vault) {
        const merged = { ...vault };
        for (const [k, v] of Object.entries(state.company ?? {})) {
          if (v) merged[k] = v;
        }
        for (const [k, v] of Object.entries(vault)) {
          if (v && !merged[k]) merged[k] = v;
        }
        state.company = merged;
        state.companySource = state.companySource
          ? `${state.companySource} + cofre`
          : "cofre de CNPJs proprios";
      }
      if (!state.company) throw new Error("Nenhuma fonte de CNPJ respondeu");
      const c = state.company;
      if (!c.legalName) throw new Error("Nao consegui os dados do CNPJ " + digits);
      log(`Fonte usada: ${state.companySource}`);

      log("--- Dados que vao para a BM ---");
      log(`CNPJ: ${c.cnpj}`);
      log(`Razao social: ${c.legalName}`);
      log(`Nome fantasia: ${c.tradeName || "-"}`);
      log(`Logradouro: ${c.street || "-"}`);
      log(`Bairro: ${c.district || "-"}`);
      log(`Complemento: ${c.complement || "-"}`);
      log(`Cidade/UF: ${c.city || "-"}/${c.state || "-"}`);
      log(`CEP: ${c.zip || "-"}`);
      log(`Telefone (CNPJ): ${c.phone || "(vai usar SMS 24h)"}`);
      log(`Atividade: ${c.activity || "-"}`);
      log("-------------------------------");
    },
  },


  {
    name: "Publicar site da empresa (CNPJ)",
    async run({ instance, state, log }) {
      if (instance.company_site) {
        // site ja existe: reaproveita (nao cria outro)
        const url = instance.company_site;
        state.site = {
          url,
          slug: url.split("/s/")[1] ?? "",
          domain: new URL(url).hostname,
          domainValue: rootDomain(),
        };
        log(`Site ja publicado (reaproveitando): ${url}`);
        return;
      }
      state.site = await publishCompanySite(instance, state.company);
      state.site.domainValue = rootDomain();
      log(`Site publicado: ${state.site.url} (dominio ${state.site.domain})`);
    },
  },
  {
    name: "Criar portfólio empresarial (BM)",
    async run({ page, instance, state, log }) {
      if (instance.bm_id) {
        state.businessId = instance.bm_id;
        log(`BM ja criada (business_id ${instance.bm_id}) — pulando criacao`);
        return;
      }
      // abre o Gerenciador de Negocios logado com o perfil (mesma aba/sessao)
      await page.goto("https://business.facebook.com/", { waitUntil: "domcontentloaded" });
      await settle(5000, 8000);

      await closePopups(page, log);

      // se caiu na tela de login do BM, entra com o perfil do Facebook ja logado
      if (/loginpage|login\.php/i.test(page.url())) {
        await clickAny(page, ["Continuar como", "Continue as", "Entrar com o Facebook", "Log in with Facebook", "Entrar"]);
        await settle(6000, 9000);
      }

      // já existe portfólio? entao apenas resolve o business_id
      let id = businessIdFrom(page.url());
      if (!id) {
        const created = await clickAny(page, [
          "Criar portfólio empresarial",
          "Criar portfólio de negócios",
          "Criar conta",
          "Create account",
          "Criar nova conta",
          "Criar",
        ]);
        if (!created) {
          await page.goto("https://business.facebook.com/overview", { waitUntil: "domcontentloaded" });
          await settle(4000, 7000);
          await clickAny(page, ["Criar portfólio", "Criar conta", "Create account", "Criar"]);
        }
        await settle(3000, 5000);

        // Modal "Create your business portfolio in Business Manager".
        // Os campos nao tem label/aria previsivel — preenchemos por posicao
        // dentro do dialog (1: nome da empresa/conta, 2: seu nome, 3: e-mail).
        const dialog = page.locator('div[role="dialog"]').last();
        const scope = (await dialog.count().catch(() => 0)) ? dialog : page;
        const inputs = scope.locator(
          'input[type="text"]:visible, input:not([type]):visible, input[type="email"]:visible',
        );
        const n = await inputs.count().catch(() => 0);
        log(`modal do portfólio: ${n} campos detectados`);

        // "Your name" ja vem preenchido pelo Facebook com o nome do perfil
        let profileName = "";
        if (n >= 2) profileName = (await inputs.nth(1).inputValue().catch(() => "")) || "";
        if (!profileName) profileName = state.company?.tradeName || state.company?.legalName || "";
        state.profileName = profileName;

        const bizName = profileName || state.cnpjDigits;
        // e-mail comercial: qualquer coisa parecida com e-mail nos dados do perfil
        // (o campo "profile_email" pode conter apenas o ID numerico do Facebook,
        // e o e-mail real costuma vir na linha colada / nas notas da instancia).
        const emailRx = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/;
        const randomGmail = () => {
          const a = ["silva","souza","lima","costa","rocha","alves","pinto","ramos","dias","melo","nunes","braga"];
          const pick = () => a[Math.floor(Math.random() * a.length)];
          return `${pick()}${pick()}${Math.floor(Math.random() * 9000 + 1000)}@gmail.com`;
        };
        const email =
          [instance.profile_email, instance.notes, instance.profile_password]
            .filter(Boolean)
            .map((v) => String(v).match(emailRx)?.[0])
            .find(Boolean) || randomGmail();


        if (n >= 1) await humanType(page, inputs.nth(0), bizName, { clear: true });
        await think(600, 1200);
        if (n >= 2 && !profileName) await humanType(page, inputs.nth(1), bizName, { clear: true });
        await think(600, 1200);
        if (n >= 3) await humanType(page, inputs.nth(2), email, { clear: true });



        // fallback por label, caso a posicao falhe
        if (!n) {
          await fillLabel(page, ["Nome da sua conta e empresa", "business and account name"], bizName);
          await fillLabel(page, ["Seu nome", "Your name"], bizName);
          await fillLabel(page, ["Seu email comercial", "business email", "E-mail"], email);
        }

        log(`Formulário: conta="${bizName}" · nome="${profileName || bizName}" · email="${email}"`);
        await think(1000, 2000);
        await clickAny(page, ["^Enviar$", "^Submit$", "^Criar$", "^Create$"]);

        await pause(12000);
        await closePopups(page, log);
        id = businessIdFrom(page.url());
      }

      if (!id) {
        // ultimo recurso: le o business_id do HTML da pagina
        const html = await page.content();
        id = html.match(/business_id=(\d{8,})/)?.[1] ?? null;
      }

      if (id) {
        state.businessId = id;
        await updateInstance(instance.id, { bm_id: id });
        log(`business_id resolvido: ${id}`);
      } else {
        log("business_id ainda nao visivel — seguindo sem ele");
      }
    },
  },

  {
    name: "Editar detalhes da empresa (CNPJ + endereço)",
    async run({ page, state, instance, log }) {
      if (isDone(instance, "detalhes")) {
        log("Detalhes da empresa ja preenchidos — pulando");
        return;
      }
      const base = state.businessId

        ? `${BM_LATEST}/settings/business_info?business_id=${state.businessId}`
        : `${BM_LATEST}/settings/business_info`;
      await page.goto(base, { waitUntil: "domcontentloaded" });
      await pause(5000);
      await closePopups(page, log);
      if (!state.businessId) {
        state.businessId = businessIdFrom(page.url());
        if (state.businessId) await updateInstance(instance.id, { bm_id: state.businessId });
      }
      log("Clicando em Editar do card 'Business details'...");
      // O Edit certo e o do card "Business details" / "Detalhes da empresa".
      // O primeiro Edit da pagina e o do portfolio (nome/foto) — nunca esse.
      let clicked = false;
      const headingRx = /^(Business details|Detalhes (da empresa|do neg[óo]cio)|Dados da empresa)$/i;
      const heading = page.getByText(headingRx).first();
      if (await heading.count().catch(() => 0)) {
        await heading.scrollIntoViewIfNeeded().catch(() => {});
        // sobe pelos ancestrais ate achar um container que tenha o botao Edit
        for (let up = 1; up <= 6 && !clicked; up++) {
          const container = heading.locator(`xpath=${"ancestor::*[" + up + "]"}`);
          const btn = container.getByRole("button", { name: /^(Editar|Edit)$/i }).first();
          if (await btn.count().catch(() => 0)) {
            await humanClick(page, btn);
            clicked = true;
          }
        }
      }
      if (!clicked) {
        // fallback: usa o Edit imediatamente seguinte ao texto do card
        const editButtons = page.getByRole("button", { name: /^(Editar|Edit)$/i });
        const total = await editButtons.count().catch(() => 0);
        if (total > 1) await humanClick(page, editButtons.nth(1));
        else await clickAny(page, ["^Editar$", "^Edit$"]);
      }
      await pause(4000);
      // Se abriu o modal errado (nome/foto do portfolio), fecha e tenta o proximo Edit.
      const wrongModal = page.locator('div[role="dialog"]').last();
      if (await wrongModal.count().catch(() => 0)) {
        const txt = (await wrongModal.innerText().catch(() => "")) || "";
        const hasAddress = /(Address|Endere[çc]o|CNPJ|Tax|Street|Logradouro)/i.test(txt);
        if (!hasAddress) {
          log("modal aberto nao e o de detalhes — fechando e tentando o proximo Editar");
          await page.keyboard.press("Escape").catch(() => {});
          await pause(1500);
          const editButtons = page.getByRole("button", { name: /^(Editar|Edit)$/i });
          const total = await editButtons.count().catch(() => 0);
          if (total > 1) await humanClick(page, editButtons.nth(1));
          await pause(4000);
        }
      }


      const c = state.company;

      // numero comercial: vem da API de SMS (sms24h); se nao houver, usa o do CNPJ
      let phone = c.phone;
      if (smsEnabled && !state.sms) {
        for (let attempt = 1; attempt <= 3 && !state.sms; attempt++) {
          try {
            state.sms = await rentNumber();
            await updateInstance(instance.id, { sms_number: state.sms.phone });
            log(`Número alugado na API de SMS: +${state.sms.phone}`);
          } catch (error) {
            log(`API de SMS (tentativa ${attempt}): ${error.message}`);
            await pause(5000);
          }
        }
      }
      if (state.sms?.phone) {
        let digits = onlyDigits(state.sms.phone);
        if (!digits.startsWith("55")) digits = `55${digits}`;
        phone = `+${digits}`;
      }
      if (!phone) log("sem número disponível para o telefone comercial");

      const dialog = page.locator('div[role="dialog"]').last();
      const scope = (await dialog.count().catch(() => 0)) ? dialog : page;

      // Pais: sempre Brasil. Pode ser <select> nativo ou combobox com busca.
      let countryOk = false;
      const nativeSelect = scope.locator("select").first();
      if (await nativeSelect.count().catch(() => 0)) {
        for (const opt of [{ label: "Brazil" }, { label: "Brasil" }, { value: "BR" }]) {
          try {
            await nativeSelect.selectOption(opt, { timeout: 4000 });
            countryOk = true;
            break;
          } catch {}
        }
      }
      if (!countryOk) {
        const country = scope
          .locator(
            '[role="combobox"], input[aria-autocomplete], [aria-label*="Country" i], [aria-label*="País" i]',
          )
          .first();
        if (await country.count().catch(() => 0)) {
          await country.click().catch(() => {});
          await pause(1000);
          await page.keyboard.type("Brazil", { delay: 90 });
          await pause(1800);
          const option = page
            .locator('[role="option"], li')
            .filter({ hasText: /^\s*(Brazil|Brasil)\s*$/i })
            .first();
          if (await option.count().catch(() => 0)) await option.click().catch(() => {});
          else await page.keyboard.press("Enter").catch(() => {});
          await pause(1000);
          countryOk = true;
        }
      }
      log(countryOk ? "País: Brasil selecionado" : "País: campo não encontrado");


      // Os campos do modal nao tem label/aria previsivel: preenche por posicao
      // (ordem do modal: razao social, endereco, endereco 2, cidade, estado,
      // CEP, telefone comercial, site).
      const inputs = scope.locator(
        'input[type="text"]:visible, input:not([type]):visible, input[type="tel"]:visible, input[type="url"]:visible, input[type="email"]:visible',
      );
      const values = [
        c.legalName,
        c.street || c.address,
        c.complement || c.district,
        c.city,
        c.state,
        c.zip,
        phone,
        state.site.url,
      ];
      const n = await inputs.count().catch(() => 0);
      log(`modal de detalhes: ${n} campos detectados`);
      for (let i = 0; i < Math.min(n, values.length); i++) {
        if (!values[i]) continue;
        await humanType(page, inputs.nth(i), String(values[i]), { clear: true });
        await think(300, 800);
      }

      // reforco por label: só preenche o que ficou vazio (evita duplicar texto)
      const only = { onlyIfEmpty: true };
      await fillLabel(page, ["Legal name of business", "Razão social"], c.legalName, only);
      await fillLabel(page, ["^Street address$", "^Endereço$"], c.street || c.address, only);
      await fillLabel(page, ["^City$", "^Cidade$"], c.city, only);
      await fillLabel(page, ["State/province/region", "Estado"], c.state, only);
      await fillLabel(page, ["Zip/postal code", "CEP"], c.zip, only);
      await fillLabel(page, ["Business phone number", "Telefone comercial"], phone, only);
      await fillLabel(page, ["Business website", "Site da empresa"], state.site.url, only);
      await fillLabel(page, ["Identificação fiscal", "Tax ID", "CNPJ"], state.cnpjDigits, only);


      log(`Preenchido: ${c.legalName} · CNPJ ${state.cnpjDigits} · tel ${phone} · site ${state.site.url}`);
      log("Salvando informações da empresa...");
      await clickAny(page, ["^Salvar$", "^Save$"]);
      await pause(7000);

      // se o modal continuar aberto com erros, avisa e tenta salvar de novo
      if (await dialog.count().catch(() => 0)) {
        const txt = await dialog.innerText().catch(() => "");
        if (/Please enter|Insira/i.test(txt)) {
          log("modal reclamou de campos — tentando salvar novamente");
          await clickAny(page, ["^Salvar$", "^Save$"]);
          await pause(6000);
        }
      }
      await updateInstance(instance.id, { company_name: c.tradeName || c.legalName });
      await markDone(instance, "detalhes");
      log("Informações da empresa salvas");
    },
  },

  {

    name: "Adicionar domínio no Meta",
    async run({ page, state, instance, log }) {
      if (!state.site?.url) throw new Error("Site institucional ainda nao publicado");
      // dominio RAIZ (o Meta rejeita subpaginas/prefixos)
      const domainValue = rootDomain();
      state.site.domainValue = domainValue;
      if (isDone(instance, "dominio")) {
        log(`Domínio ja adicionado (${domainValue}) — pulando`);
        return;
      }


      const url = state.businessId
        ? `${BM_LATEST}/settings/domains?business_id=${state.businessId}`
        : `${BM_LATEST}/settings/domains`;
      await page.goto(url, { waitUntil: "domcontentloaded" });
      await pause(6000);
      await closePopups(page, log);

      log("Clicando em Adicionar (domínios)...");
      await clickAny(page, ["Adicionar", "Add domain", "^Add$", "Adicionar domínio"]);
      await pause(3000);

      // modal "O que você quer fazer?" -> Criar um domínio
      const created = await clickAny(page, [
        "Create a domain",
        "Criar um domínio",
        "Criar domínio",
      ]);
      if (created) {
        log("Selecionado 'Create a domain'");
        await pause(3000);
      }

      const filled = await fillLabel(
        page,
        ["Seu domínio", "Your domain", "Domínio", "Domain", "exemplo", "example"],
        domainValue,
      );
      if (!filled) {
        // fallback: primeiro input visivel do dialog
        const dialog = page.locator('div[role="dialog"]').last();
        const scope = (await dialog.count().catch(() => 0)) ? dialog : page;
        const input = scope
          .locator('input[type="text"]:visible, input:not([type]):visible')
          .first();
        if (await input.count().catch(() => 0)) {
          await humanType(page, input, domainValue, { clear: true });
        } else {
          throw new Error("Campo de dominio nao encontrado");
        }
      }
      log(`Domínio: ${domainValue}`);
      await think(800, 1500);
      await clickAny(page, ["^Adicionar$", "^Add$", "Avançar", "Next", "Salvar", "Save"]);
      await pause(9000);
      await markDone(instance, "dominio");
    },
  },
  {
    name: "Copiar meta tag e publicar no site",
    async run({ page, state, instance, log }) {
      if (isDone(instance, "metatag") && instance.meta_tag) {
        log("Meta tag ja publicada no site — pulando");
        return;
      }
      const readTag = async () => {

        const html = await page.content();
        const m =
          html.match(/facebook-domain-verification"\s+content="([a-z0-9]{10,})"/i) ??
          html.match(/content="([a-z0-9]{20,})"\s+name="facebook-domain-verification"/i) ??
          html.match(/facebook-domain-verification[^a-z0-9]{1,40}([a-z0-9]{20,})/i);
        if (m?.[1]) return m[1];
        // alguns layouts mostram a tag dentro de input/textarea (value nao aparece no HTML)
        return await page
          .evaluate(() => {
            const els = Array.from(document.querySelectorAll("input, textarea"));
            for (const el of els) {
              const v = el.value || "";
              const hit = v.match(/facebook-domain-verification[^a-z0-9]{1,40}([a-z0-9]{20,})/i);
              if (hit) return hit[1];
            }
            return null;
          })
          .catch(() => null);
      };

      const openMetaTag = async () => {
        await clickAny(page, [
          "Adicionar uma metatag",
          "Add a meta-tag",
          "Add a meta tag",
          "metatag",
          "meta-tag",
          "Meta-tag",
        ]);
        await pause(3500);
      };

      await openMetaTag();
      let token = await readTag();

      if (!token && state.site?.domainValue) {
        // se o dialogo fechou, abre o dominio recem-adicionado na lista
        log("Reabrindo o domínio na lista para pegar a meta tag...");
        const row = page.getByText(state.site.domainValue, { exact: false }).first();
        if (await row.count().catch(() => 0)) {
          await row.click({ timeout: 8000 }).catch(() => {});
          await pause(5000);
        }
        await openMetaTag();
        token = await readTag();
      }

      if (!token) {
        await pause(5000);
        token = await readTag();
      }
      if (!token) throw new Error("Meta tag de verificacao nao encontrada na tela de dominios");

      const tag = `<meta name="facebook-domain-verification" content="${token}" />`;
      await saveMetaTag(state.site.slug, tag);
      await updateInstance(instance.id, { meta_tag: tag });
      await markDone(instance, "metatag");
      log(`Meta tag publicada no site: ${token}`);
      // da tempo do site publicar a tag antes de verificar
      await pause(12000);
    },
  },

  {
    name: "Verificar o domínio",
    async run({ page, instance, log }) {
      if (isDone(instance, "dominio_verificado")) {
        log("Domínio ja verificado — pulando");
        return;
      }
      for (let attempt = 1; attempt <= 3; attempt++) {
        const ok = await clickAny(page, [
          "Verificar domínio",
          "Verify domain",
          "^Verificar$",
          "^Verify$",
        ]);
        if (!ok) log("botao Verificar dominio nao encontrado");
        await pause(9000);
        const body = await page.content();
        if (/Verificado|Verified/i.test(body) && !/Não verificado|Not verified/i.test(body)) {
          log("Dominio verificado");
          await markDone(instance, "dominio_verificado");
          return;
        }
        log(`Verificacao ainda nao confirmada (tentativa ${attempt}/3)`);
        await pause(8000);
      }
      log("Verificacao solicitada — o Meta pode levar alguns minutos para ler a meta tag");
    },
  },
  {
    name: "Criar WABA do WhatsApp",
    async run({ page, instance, state, log }) {
      if (instance.waba_created) {
        log("WABA ja criada — pulando");
        return;
      }
      const url = state.businessId
        ? `${BM_LATEST}/settings/whatsapp_account?business_id=${state.businessId}`
        : `${BM_LATEST}/settings/whatsapp_account`;
      await page.goto(url, { waitUntil: "domcontentloaded" });
      await pause(7000);
      await closePopups(page, log);


      const displayName =
        state.profileName ||
        instance.profile_name ||
        state.company?.tradeName ||
        state.company?.legalName ||
        instance.name;

      await clickAny(page, ["Adicionar", "^Add$", "Criar", "Create"]);
      await pause(2500);
      // menu que abre depois do "Adicionar"
      await clickAny(page, [
        "Criar uma conta do WhatsApp",
        "Create a WhatsApp",
        "Criar nova conta",
        "Create new",
      ]);
      await pause(4000);

      const dialog = page.locator('div[role="dialog"]').last();
      const scope = (await dialog.count().catch(() => 0)) ? dialog : page;

      // Nome de exibicao
      let named = await fillLabel(
        page,
        ["Nome de exibição do WhatsApp Business", "WhatsApp Business display name", "Nome de exibição", "Display name"],
        displayName,
      );
      if (!named) {
        const input = scope
          .locator('input[type="text"]:visible, input:not([type]):visible')
          .first();
        if (await input.count().catch(() => 0)) {
          await humanType(page, input, displayName, { clear: true });
          named = true;
        }
      }
      log(`WABA nome: ${displayName}${named ? "" : " (campo nao encontrado)"}`);

      // Categoria: "Outro" / "Other"
      await think(800, 1500);
      const nativeSelect = scope.locator("select:visible").first();
      if (await nativeSelect.count().catch(() => 0)) {
        await nativeSelect
          .selectOption({ label: /Outro|Other/i }, { timeout: 4000 })
          .catch(() => {});
      } else {
        const combo = scope
          .locator('[role="combobox"]:visible, [role="button"][aria-haspopup="listbox"]:visible')
          .first();
        if (await combo.count().catch(() => 0)) {
          const current = (await combo.textContent().catch(() => "")) ?? "";
          if (!/Outro|Other/i.test(current)) {
            await humanClick(page, combo);
            await pause(1500);
            const opt = page.getByRole("option", { name: /^\s*(Outro|Other)\s*$/i }).first();
            if (await opt.count().catch(() => 0)) await humanClick(page, opt);
            else await clickAny(page, ["^Outro$", "^Other$"]);
            await pause(1200);
          }
        }
      }
      log("Categoria: Outro");

      await think(1000, 2000);
      await clickAny(page, ["^Continuar$", "^Continue$", "^Criar$", "^Create$", "Avançar", "Next"]);
      await pause(7000);

      await updateInstance(instance.id, { waba_created: true });
      log("WABA criada — fechando a janela do WhatsApp");

      // "depois so fecha": fecha o modal sem cadastrar numero
      await clickAny(page, ["^Fechar$", "^Close$", "Cancelar", "Cancel", "Concluir", "Done"]);
      await pause(1500);
      await page.keyboard.press("Escape").catch(() => {});
      await pause(2000);
    },
  },
  {
    name: "Gerar número via API de SMS (após a WABA)",
    async run({ page, instance, state, log }) {
      if (!smsEnabled) {
        log("API de SMS nao configurada — etapa ignorada");
        return;
      }
      const rented = state.sms ?? (await rentNumber());
      state.sms = rented;
      log(`Número: ${rented.phone}`);
      await updateInstance(instance.id, { sms_number: rented.phone });

      await fillLabel(page, ["Telefone", "Phone"], `+${rented.phone}`);
      await clickAny(page, ["Enviar código", "Send code", "Continuar", "Continue"]);
      await pause(3000);
    },
  },
  {
    name: "Confirmar código SMS (você avisa no painel)",
    async run({ page, instance, state, log }) {
      if (!state.sms) {
        log("sem numero — etapa ignorada");
        return;
      }

      // Pausa intencional: o usuario avisa pelo painel quando o SMS chegar.
      // Chromium fica aberto nesta tela e a rotina nao reinicia.
      await updateInstance(instance.id, {
        status: "analise_pendente",
        notes: "SMS: aguardando você avisar no painel. Quando receber, clique em Continuar após SMS.",
      });
      log("PAUSADO NO SMS — quando receber, clique em 'Continuar após SMS' no painel.");
      await waitForInstanceStatus(instance.id, "rodando");
      log("Confirmação recebida no painel — buscando e preenchendo o código SMS.");

      const code = await waitCode(state.sms.id);
      log(`Código SMS: ${code}`);
      await fillLabel(page, ["Código", "Code", "Confirmation"], code);
      await clickAny(page, ["Confirmar", "Confirm", "Verificar", "Verify"]);
      await finishNumber(state.sms.id);
      await updateInstance(instance.id, {
        status: "rodando",
        notes: "SMS confirmado — rotina finalizada.",
      });
      await pause(4000);
    },
  },
];



export default steps;

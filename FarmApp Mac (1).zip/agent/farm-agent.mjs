#!/usr/bin/env node
import { MAX_CONCURRENCY, POLL_INTERVAL_MS } from "./lib/config.mjs";
import { listInstances, login, restoreSession, updateInstance, ensureSession } from "./lib/api.mjs";
import { openProfile } from "./lib/browser.mjs";
import steps from "./tasks/default.mjs";

const args = process.argv.slice(2);
const command = args[0] ?? "help";

function flag(name) {
  const i = args.indexOf(`--${name}`);
  return i >= 0 ? args[i + 1] : undefined;
}

function stamp() {
  return new Date().toLocaleTimeString("pt-BR");
}

const running = new Set();

async function runInstance(instance) {
  if (running.has(instance.id)) return;
  running.add(instance.id);
  const log = (msg) => console.log(`[${stamp()}] ${instance.name} :: ${msg}`);
  let context;
  try {
    await ensureSession();
    log("abrindo perfil...");
    await updateInstance(instance.id, {

      status: "rodando",
      step: 0,
      total_steps: steps.length,
    });
    const opened = await openProfile(instance);
    context = opened.context;
    const state = {};
    for (let i = 0; i < steps.length; i++) {
      const step = steps[i];
      log(`passo ${i + 1}/${steps.length}: ${step.name}`);
      await step.run({ page: opened.page, context, instance, log, state });
      await updateInstance(instance.id, { step: i + 1, total_steps: steps.length });
    }
    await updateInstance(instance.id, {
      status: "concluido",
      step: steps.length,
      total_steps: steps.length,
    });
    log("concluido");
  } catch (error) {
    console.error(`[${stamp()}] ${instance.name} :: erro -> ${error.message}`);
    await updateInstance(instance.id, {
      status: "erro",
      notes: `Agente: ${error.message}`.slice(0, 500),
    });
    // mantem o navegador aberto para voce corrigir manualmente (FARM_KEEP_OPEN=false desliga)
    if (process.env.FARM_KEEP_OPEN !== "false" && context) {
      const secs = Number(process.env.FARM_KEEP_OPEN_SECONDS ?? 0);
      if (secs > 0) {
        console.error(`[${stamp()}] ${instance.name} :: janela aberta por ${secs}s`);
        await new Promise((r) => setTimeout(r, secs * 1000));
      } else {
        console.error(
          `[${stamp()}] ${instance.name} :: janela FICA ABERTA para correcao manual. Feche o Chromium quando terminar.`
        );
        // espera o usuario fechar a janela manualmente
        await new Promise((resolve) => {
          context.on("close", resolve);
          const timer = setInterval(async () => {
            const pages = context.pages();
            if (!pages.length) {
              clearInterval(timer);
              resolve();
            }
          }, 5000);
        });
      }
    }
  } finally {
    await context?.close().catch(() => {});
    running.delete(instance.id);
  }
}


async function runQueue(instances) {
  const queue = [...instances];
  const workers = Array.from({ length: Math.min(MAX_CONCURRENCY, queue.length) }, async () => {
    while (queue.length) {
      const next = queue.shift();
      if (next) await runInstance(next);
    }
  });
  await Promise.all(workers);
}

async function main() {
  if (command === "login") return login();

  if (command === "help" || command === "--help") {
    console.log(`FARM agent (macOS / Windows / Linux)

  npm run login                      autentica com sua conta do painel
  node farm-agent.mjs list           lista as instancias do painel
  node farm-agent.mjs run --instance <short_id|all>
  node farm-agent.mjs watch          fica ouvindo o painel e roda o que estiver "Rodando"
`);
    return;
  }

  await restoreSession();

  if (command === "list") {
    const instances = await listInstances();
    for (const i of instances) {
      console.log(
        `${i.short_id.padEnd(10)} ${i.status.padEnd(18)} ${i.step}/${i.total_steps}  ${i.name}`
      );
    }
    console.log(`\n${instances.length} instancia(s).`);
    return;
  }

  if (command === "run") {
    const target = flag("instance");
    if (!target) {
      console.error("Informe --instance <short_id|all>");
      process.exit(1);
    }
    const instances =
      target === "all" ? await listInstances() : await listInstances({ shortId: target });
    if (!instances.length) {
      console.error("Nenhuma instancia encontrada.");
      process.exit(1);
    }
    await runQueue(instances);
    return;
  }

  if (command === "watch") {
    console.log(
      `Ouvindo o painel a cada ${POLL_INTERVAL_MS / 1000}s (concorrencia ${MAX_CONCURRENCY}). Ctrl+C para sair.`
    );
    const tick = async () => {
      try {
        const pending = (await listInstances({ status: "rodando" })).filter(
          (i) => !running.has(i.id)
        );
        if (pending.length) await runQueue(pending);
      } catch (error) {
        console.error(`[${stamp()}] watch: ${error.message}`);
      }
    };
    await tick();
    setInterval(tick, POLL_INTERVAL_MS);
    return;
  }

  console.error(`Comando desconhecido: ${command}`);
  process.exit(1);
}

main().catch((error) => {
  console.error(error.message);
  process.exit(1);
});

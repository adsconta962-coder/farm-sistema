# FARM Agent (local)

Agente local que lê as instâncias do painel, abre um **perfil de navegador real
e persistente** para cada uma (com o proxy da linha) e executa a rotina de farm,
atualizando status e progresso de volta no painel em tempo real.

Funciona no **macOS (Intel e Apple Silicon)**, Windows e Linux.

## Instalação (uma vez)

```bash
cd agent
npm install          # instala o Chromium do Playwright automaticamente
npm run login        # e-mail e senha da sua conta do painel
```

O arquivo `agent/.env` já vem preenchido com a conexão do painel.
Perfis e sessão ficam em `~/.farmapp/`.

## Uso

```bash
node farm-agent.mjs list                        # lista as instâncias
node farm-agent.mjs run --instance ab12cd        # roda uma instância
node farm-agent.mjs run --instance all           # roda todas
node farm-agent.mjs watch                       # fica ouvindo o painel
```

O botão **Copiar comando** de cada linha do painel gera exatamente o comando
`run --instance <id>` daquela instância.

No modo `watch`, tudo que você marcar como **Rodando** no painel é executado
automaticamente pelo agente (até `FARM_CONCURRENCY` perfis ao mesmo tempo).

## Perfis e proxy

- Cada instância tem seu próprio perfil em `~/.farmapp/profiles/<short_id>`
  (cookies e login continuam salvos entre execuções).
- Proxy aceito nos formatos: `host:porta`, `host:porta:usuario:senha`
  ou `http://usuario:senha@host:porta`.

## Personalizar a rotina de farm

Edite `agent/tasks/default.mjs`. Cada item do array `steps` é um passo; o
progresso no painel avança automaticamente a cada passo concluído.
Defina o site alvo em `FARM_SITE_URL` no `.env`.

## Opções do `.env`

| Variável | Padrão | Função |
| --- | --- | --- |
| `FARM_SITE_URL` | example.com | site onde o farm roda |
| `FARM_CONCURRENCY` | 2 | perfis simultâneos |
| `FARM_POLL_MS` | 15000 | intervalo do `watch` |
| `FARM_HEADLESS` | false | `true` roda sem janela |

## Rotina FARM BM (13 etapas)

`agent/tasks/default.mjs` executa, localmente no seu Mac, o mesmo fluxo do agente
de Windows:

1. Abrir perfil do Facebook
2. Login com e-mail/senha da linha do painel
3. Consultar o CNPJ (só o número) e obter razão social, endereço e telefone
4. Publicar o site institucional da empresa (hospedado no próprio painel em `/s/<slug>`)
5. Abrir o Business Manager e criar a BM
6. Preencher as informações da empresa
7. Alugar número na API de SMS (SMS 24h)
8. Confirmar o código recebido
9. Adicionar o domínio do site em Domínios
10. Copiar a meta tag do Facebook e publicá-la no site
11. Verificar o domínio
12. Criar a WABA do WhatsApp (sem número)
13. Enviar as informações para a verificação da BM

Preencha na instância: **e-mail, senha, proxy e CNPJ**. A API de SMS vai no
`.env` (`FARM_SMS_API_KEY`); sem ela as etapas 7 e 8 são ignoradas.

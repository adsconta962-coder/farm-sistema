CREATE TABLE public.own_companies (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  cnpj text NOT NULL,
  legal_name text,
  trade_name text,
  owner_name text,
  email text,
  phone text,
  street text,
  number text,
  complement text,
  district text,
  city text,
  state text,
  zip text,
  website text,
  notes text,
  is_default boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, cnpj)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.own_companies TO authenticated;
GRANT ALL ON public.own_companies TO service_role;

ALTER TABLE public.own_companies ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own companies select" ON public.own_companies FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own companies insert" ON public.own_companies FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own companies update" ON public.own_companies FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own companies delete" ON public.own_companies FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TRIGGER own_companies_updated_at BEFORE UPDATE ON public.own_companies
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
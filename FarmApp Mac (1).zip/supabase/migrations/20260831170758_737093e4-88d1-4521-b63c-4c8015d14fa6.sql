ALTER TABLE public.instances
  ADD COLUMN IF NOT EXISTS cnpj text,
  ADD COLUMN IF NOT EXISTS company_name text,
  ADD COLUMN IF NOT EXISTS company_site text,
  ADD COLUMN IF NOT EXISTS meta_tag text,
  ADD COLUMN IF NOT EXISTS bm_id text,
  ADD COLUMN IF NOT EXISTS waba_created boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS sms_number text;

CREATE TABLE IF NOT EXISTS public.company_sites (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  instance_id uuid REFERENCES public.instances(id) ON DELETE CASCADE,
  slug text NOT NULL UNIQUE,
  company_name text NOT NULL,
  cnpj text,
  email text,
  phone text,
  address text,
  about text,
  meta_tag text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.company_sites TO authenticated;
GRANT SELECT ON public.company_sites TO anon;
GRANT ALL ON public.company_sites TO service_role;

ALTER TABLE public.company_sites ENABLE ROW LEVEL SECURITY;

CREATE POLICY "public can read company sites"
  ON public.company_sites FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "owner manages company sites"
  ON public.company_sites FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "owner updates company sites"
  ON public.company_sites FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "owner deletes company sites"
  ON public.company_sites FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TRIGGER update_company_sites_updated_at
  BEFORE UPDATE ON public.company_sites
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
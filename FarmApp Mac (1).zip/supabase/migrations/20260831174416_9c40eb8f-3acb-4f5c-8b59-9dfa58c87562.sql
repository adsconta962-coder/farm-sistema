ALTER TABLE public.instances
  ADD COLUMN IF NOT EXISTS soak_mode boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS direct_bm boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS invert_flow boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS auto_allocate boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS site_theme text NOT NULL DEFAULT 'azul';